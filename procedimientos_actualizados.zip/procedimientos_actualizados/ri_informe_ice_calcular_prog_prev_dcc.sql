-- =============================================================================
-- Autor:			H�ctor Cruz
-- Fecha:           08-03-2019
-- Empresa:			Komatsu Cummins
-- Proyecto:		Ajustes Elamp
-- Requerimiento:	
-- Descripci�n:		SE REALIZA EL CALCULO DE SUB PAE
-- MODIFICACIONES:
-- FECHA                  AUTOR                               MODIFICACION
-- =============================================================================
-- 25-04-2019    H�ctor Cruz              Se realiza ajuste para que considere elementos
--                                        de FY 2019
-- 13-04-2020    H�ctor Cruz              Se realiza ajuste para que considere elementos
--                                        de FY 2020
-- =============================================================================
ALTER PROCEDURE ri_informe_ice_calcular_prog_prev_dcc
(
    @idn_area INTEGER,
    @considera_hijas BIT,
    @fecha_inicio DATETIME,
    @fecha_fin DATETIME,
    @fecha_actual DATETIME,
    @id_sub_elemento_qpro INTEGER 
)
AS
BEGIN
    DECLARE @realizadas INTEGER;
    DECLARE @ok_codigos VARCHAR(MAX);
	DECLARE @ok1_total INTEGER; 
    DECLARE @atrasadas FLOAT;
    DECLARE @fp FLOAT;
    DECLARE @no_realizadas FLOAT;
    DECLARE @nok_codigos VARCHAR(MAX);
    DECLARE @codigo_area VARCHAR(20);
    
    SET @realizadas = 0;
    SET @atrasadas = 0;
    SET @fp = 0;
    SET @no_realizadas = 0;
	SET @ok1_total = 0;

    
    SET @ok_codigos = '''''';
    SET @nok_codigos = '''''';
        
    BEGIN TRY
    
        DECLARE @TMP_AREAS TABLE
        (
        	idn_area INTEGER
        )
        
        INSERT INTO @TMP_AREAS(idn_area)
        VALUES(@idn_area);
        
        IF (@considera_hijas = '1')
            BEGIN
        
                ;WITH CTE(depende_de, idn_area, nombre_area, nivel)
            		AS
            		(
              			SELECT depende_de, idn_area, nombre_area, 1 as nivel 
              			FROM Area WHERE (depende_de = @idn_area) 
              			UNION ALL	
              			SELECT A.depende_de, A.idn_area, A.nombre_area, nivel + 1 
              			FROM Area A
              			INNER JOIN CTE D ON (A.depende_de = D.idn_area)
                                	    	
            		)
                
                INSERT INTO @TMP_AREAS(idn_area)
                SELECT idn_area FROM CTE;
            END
                
        SELECT @realizadas = @realizadas + 1, @ok_codigos = @ok_codigos + ',''' + CONVERT(VARCHAR, Actividades_Especificas.codigo) + '''', @ok1_total = @ok1_total + 1
        FROM Actividades_Especificas 
        INNER JOIN Usuario ON (ltrim(rtrim(Actividades_Especificas.asignada_a)) = ltrim(rtrim(Usuario.rut_usuario)))
        WHERE (Actividades_Especificas.realizado = 1) AND (convert(datetime,convert(char(10),Actividades_Especificas.fecha_respuesta,103),103) <= convert(datetime,convert(char(10),hasta,103),103))
              AND (Usuario.idn_area IN(SELECT idn_area FROM @TMP_AREAS))
              -- AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 31) AND (asignada_por <> '') AND (codigo <> '') -- 25-04-2019: HC => Se cambia id_elemento_qpro 29 por 31
              AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 32) AND (asignada_por <> '') AND (codigo <> '') -- 13-04-2020: HC => Se cambia id_elemento_qpro 31 por 32
              AND (id_sub_elemento_qpro = @id_sub_elemento_qpro);
        
        SELECT @atrasadas = @atrasadas + 1, @nok_codigos = @nok_codigos + ',''' + CONVERT(VARCHAR, Actividades_Especificas.codigo) + '''', @ok1_total = @ok1_total + 1
        FROM Actividades_Especificas 
        INNER JOIN Usuario ON (ltrim(rtrim(Actividades_Especificas.asignada_a)) = ltrim(rtrim(Usuario.rut_usuario)))
        WHERE (realizado IS NULL) AND (convert(datetime,convert(char(10),getdate(),103),103) > convert(datetime,convert(char(10),hasta,103),103))
              AND (Usuario.idn_area IN(SELECT idn_area FROM @TMP_AREAS))
              -- AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 31) AND (asignada_por <> '') AND (codigo <> '') -- 25-04-2019: HC => Se cambia id_elemento_qpro 29 por 31
              AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 32) AND (asignada_por <> '') AND (codigo <> '') -- 13-04-2020: HC => Se cambia id_elemento_qpro 31 por 32
              AND (id_sub_elemento_qpro = @id_sub_elemento_qpro); 
 
        SELECT @fp = @fp + 0.5, @ok_codigos = @ok_codigos + ',''' + CONVERT(VARCHAR, Actividades_Especificas.codigo) + '''', @ok1_total = @ok1_total + 1
        FROM Actividades_Especificas                                     
        INNER JOIN Usuario ON (ltrim(rtrim(Actividades_Especificas.asignada_a)) = ltrim(rtrim(Usuario.rut_usuario)))
        WHERE (realizado = 1) AND (convert(datetime,convert(char(10),Actividades_Especificas.fecha_respuesta,103),103) > convert(datetime,convert(char(10),hasta,103),103))
              AND (Usuario.idn_area IN(SELECT idn_area FROM @TMP_AREAS))              
              -- AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 31) AND (asignada_por <> '') AND (codigo <> '') -- 25-04-2019: HC => Se cambia id_elemento_qpro 29 por 31
              AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 32) AND (asignada_por <> '') AND (codigo <> '') -- 13-04-2020: HC => Se cambia id_elemento_qpro 31 por 32
              AND (id_sub_elemento_qpro = @id_sub_elemento_qpro); 
       
        SELECT @no_realizadas = @no_realizadas + 1, @nok_codigos = @nok_codigos + ',''' + CONVERT(VARCHAR, Actividades_Especificas.codigo) + '''', @ok1_total = @ok1_total + 1    			        
        FROM Actividades_Especificas 
        INNER JOIN Usuario ON (ltrim(rtrim(Actividades_Especificas.asignada_a)) = ltrim(rtrim(Usuario.rut_usuario)))
        WHERE (realizado is null) AND (convert(datetime,convert(char(10),getdate(),103),103) > convert(datetime,convert(char(10),hasta,103),103))
              AND (fecha_respuesta is null) 
              AND (Usuario.idn_area IN(SELECT idn_area FROM @TMP_AREAS))
              -- and id_sub_elemento_qpro <> 140 and id_elemento_qpro=16  and id_sub_elemento_qpro=@id_sub_elemento_qpro and asignada_por<>'' and codigo<>''
              -- AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 31) AND (asignada_por <> '') AND (codigo <> '') -- 25-04-2019: HC => Se cambia id_elemento_qpro 29 por 31
              AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 32) AND (asignada_por <> '') AND (codigo <> '') -- 13-04-2020: HC => Se cambia id_elemento_qpro 31 por 32
              AND (id_sub_elemento_qpro = @id_sub_elemento_qpro);
        
        SELECT (@realizadas + @fp) AS ok, @ok_codigos AS ok_codigos, 
              (@atrasadas + @no_realizadas) as nok, @nok_codigos AS nok_codigos,
				@ok1_total as ok1_total;
        
    END TRY
    BEGIN CATCH

        SELECT 0 AS ok, '''''' AS ok_codigos, 
               0 nok,  '''''' AS nok_codigos,
			   0  AS ok1_total;            
    
    END CATCH      
END;
GO







