-- =============================================================================
-- Autor:			H�ctor Cruz
-- Fecha:           08-03-2019
-- Empresa:			Komatsu Cummins
-- Proyecto:		Ajustes Elamp
-- Requerimiento:	
-- Descripci�n:		SE REALIZA EL CALCULO DE SUB PAE
-- MODIFICACIONES:
-- FECHA                  AUTOR                               MODIFICACION
-- =============================================================================
-- 24-04-2019    H�ctor Cruz              Se realiza ajuste para que considere elementos
--                                        de FY 2019
-- 13-04-2020    H�ctor Cruz              Se realiza ajuste para que considere elementos
--                                        de FY 2020
-- =============================================================================
ALTER PROCEDURE ri_informe_ice_calcular_sub_pae
(
    @idn_area INTEGER,
    @considera_hijas BIT,
    @fecha_inicio DATETIME,
    @fecha_fin DATETIME,
    @fecha_actual DATETIME    
)
AS
BEGIN
    DECLARE @realizadas INTEGER;
    DECLARE @ok_codigos VARCHAR(MAX);
	DECLARE @ok1_total INTEGER; 
    DECLARE @atrasadas FLOAT;
    DECLARE @fp FLOAT;
    DECLARE @no_realizadas FLOAT;
    DECLARE @nok_codigos VARCHAR(MAX);
    DECLARE @codigo_area VARCHAR(20);
    
    SET @realizadas = 0;
    SET @atrasadas = 0;
    SET @fp = 0;
    SET @no_realizadas = 0;
	SET @ok1_total = 0;

    
    SET @ok_codigos = '''''';
    SET @nok_codigos = '''''';
        
    BEGIN TRY
    
        DECLARE @TMP_AREAS TABLE
        (
        	idn_area INTEGER
        )
        
        INSERT INTO @TMP_AREAS(idn_area)
        VALUES(@idn_area);
        
        IF (@considera_hijas = '1')
            BEGIN
        
                ;WITH CTE(depende_de, idn_area, nombre_area, nivel)
            		AS
            		(
              			SELECT depende_de, idn_area, nombre_area, 1 as nivel 
              			FROM Area WHERE (depende_de = @idn_area) 
              			UNION ALL	
              			SELECT A.depende_de, A.idn_area, A.nombre_area, nivel + 1 
              			FROM Area A
              			INNER JOIN CTE D ON (A.depende_de = D.idn_area)
                                	    	
            		)
                
                INSERT INTO @TMP_AREAS(idn_area)
                SELECT idn_area FROM CTE;
            END
                
        SELECT @realizadas = @realizadas + 1, @ok_codigos = @ok_codigos + ',''' + CONVERT(VARCHAR, Actividades_Especificas.codigo) + '''', @ok1_total = @ok1_total + 1
        FROM Actividades_Especificas 
        INNER JOIN  Usuario ON (ltrim(rtrim(Actividades_Especificas.asignada_a)) = ltrim(rtrim(Usuario.rut_usuario)))
        WHERE (Actividades_Especificas.realizado = 1) 
              AND (convert(datetime,convert(char(10),Actividades_Especificas.fecha_respuesta,103),103) <= convert(datetime,convert(char(10),hasta,103),103))
              AND (Usuario.idn_area IN(SELECT idn_area FROM @TMP_AREAS))
              -- AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 31) AND (asignada_por <> '') AND (codigo <> '') -- 24-04-2019: HC => Se cambia id_elemento_qpro 29 por 31
              AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 32) AND (asignada_por <> '') AND (codigo <> '') -- 13-04-2020: HC => Se cambia id_elemento_qpro 31 por 32
--AND ((DATEDIFF(D, convert(datetime, fecha_respuesta,103), convert(datetime, hasta , 103))) >= 0)
        /*
        
        	FROM Elemento_QPRO EQ
            INNER JOIN Sub_Elemento_Qpro SQ ON (EQ.id_elemento_qpro = SQ.id_elemento_qpro)
            INNER JOIN Clasificacion_Act_Especifica CAE ON (EQ.id_clasificacion_act_especifica = CAE.id_clasificacion_act_especifica) 
            RIGHT OUTER JOIN actividad AC 
            INNER JOIN Asignar_tareas_especificas ATE ON (AC.idn_correlativo = ATE.idn_correlativo )
            INNER JOIN Usuario U_1 ON LTRIM(RTRIM(AC.rut_elamp)) = LTRIM(RTRIM(U_1.rut_usuario)) 
            INNER JOIN Usuario U_2 ON LTRIM(RTRIM(ATE.rut_asignado)) = LTRIM(RTRIM(U_2.rut_usuario)) 
            INNER JOIN Area A ON U_2.idn_area = A.idn_area ON 
        													(SQ.id_sub_elemento_qpro = ATE.id_sub_elemento_qpro)
        	WHERE (EQ.id_elemento_QPro = 14) and SQ.id_sub_elemento_qpro <> 140
        		  AND
        		  (convert(datetime, ATE.f_inic,103) between 
        			convert(datetime, @fecha_inicio,103) and convert(datetime,@fecha_fin,103))
        		 AND (A.idn_area IN (SELECT idn_area FROM @TMP_AREAS))
        		 AND (ATE.estado = 1)
        		 AND (CONVERT(VARCHAR, ATE.fecha_respuesta, 103) != '01/01/1900')
        		 and ((DATEDIFF(D, convert(datetime, ATE.fecha_respuesta,103), convert(datetime, ATE.f_fin , 103))) >= 0)*/
        
        SELECT @atrasadas = @atrasadas + 1, @nok_codigos = @nok_codigos + ',''' + CONVERT(VARCHAR, Actividades_Especificas.codigo) + '''', @ok1_total = @ok1_total + 1
        FROM  Actividades_Especificas 
        INNER JOIN Usuario ON (ltrim(rtrim(Actividades_Especificas.asignada_a)) = ltrim(rtrim(Usuario.rut_usuario)))
        WHERE (realizado IS NULL) AND (convert(datetime,convert(char(10),getdate(),103),103) > convert(datetime,convert(char(10),hasta,103),103))
                AND (Usuario.idn_area IN(SELECT idn_area FROM @TMP_AREAS))
                -- AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 31) AND (asignada_por<>'') AND (codigo <> ''); -- 24-04-2019: HC => Se cambia id_elemento_qpro 29 por 31
                AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 32) AND (asignada_por<>'') AND (codigo <> ''); -- 13-04-2020: HC => Se cambia id_elemento_qpro 31 por 32
--AND ((DATEDIFF(D, convert(datetime, @fecha_actual,103), convert(datetime, hasta , 103))) < 0)

        	
 /*       	FROM Elemento_QPRO EQ
            INNER JOIN Sub_Elemento_Qpro SQ ON (EQ.id_elemento_qpro = SQ.id_elemento_qpro)
            INNER JOIN Clasificacion_Act_Especifica CAE ON (EQ.id_clasificacion_act_especifica = CAE.id_clasificacion_act_especifica) 
            RIGHT OUTER JOIN actividad AC 
            INNER JOIN Asignar_tareas_especificas ATE ON (AC.idn_correlativo = ATE.idn_correlativo )
            INNER JOIN Usuario U_1 ON LTRIM(RTRIM(AC.rut_elamp)) = LTRIM(RTRIM(U_1.rut_usuario)) 
            INNER JOIN Usuario U_2 ON LTRIM(RTRIM(ATE.rut_asignado)) = LTRIM(RTRIM(U_2.rut_usuario)) 
            INNER JOIN Area A ON U_2.idn_area = A.idn_area ON 
        													(SQ.id_sub_elemento_qpro = ATE.id_sub_elemento_qpro)
        	WHERE (EQ.id_elemento_QPro = 14) and SQ.id_sub_elemento_qpro <> 140
        		  AND
        		  (convert(datetime, ATE.f_inic,103) between 
        			convert(datetime, @fecha_inicio,103) and convert(datetime, @fecha_fin,103))
        		 AND (ATE.estado != 1)
        		 AND (A.idn_area IN (SELECT idn_area FROM @TMP_AREAS))
        		 AND ((CONVERT(char(10), ATE.fecha_respuesta, 103) = '01/01/1900') OR (ATE.fecha_respuesta is null))
        		 AND ((DATEDIFF(D, convert(datetime, @fecha_actual, 103), CONVERT(DATETIME, ATE.f_fin, 103))) < 0)*/
 
         SELECT @fp = @fp + 0.5, @ok_codigos = @ok_codigos + ',''' + CONVERT(VARCHAR, Actividades_Especificas.codigo) + '''', @ok1_total = @ok1_total + 1
         FROM  Actividades_Especificas 
         INNER JOIN Usuario ON (ltrim(rtrim(Actividades_Especificas.asignada_a)) = ltrim(rtrim(Usuario.rut_usuario)))
         WHERE (realizado = 1) AND (convert(datetime,convert(char(10),Actividades_Especificas.fecha_respuesta,103),103) > convert(datetime,convert(char(10),hasta,103),103))
                AND (Usuario.idn_area IN(SELECT idn_area FROM @TMP_AREAS))
                -- AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 31) AND (asignada_por <> '') AND (codigo <> ''); -- 24-04-2019: HC => Se cambia id_elemento_qpro 29 por 31
                AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 32) AND (asignada_por <> '') AND (codigo <> ''); -- 13-04-2020: HC => Se cambia id_elemento_qpro 31 por 32
--AND ((DATEDIFF(D, convert(datetime, fecha_respuesta, 103), CONVERT(DATETIME, hasta, 103))) < 0)

        	
/*        	FROM Elemento_QPRO EQ
            INNER JOIN Sub_Elemento_Qpro SQ ON (EQ.id_elemento_qpro = SQ.id_elemento_qpro)
            INNER JOIN Clasificacion_Act_Especifica CAE ON (EQ.id_clasificacion_act_especifica = CAE.id_clasificacion_act_especifica) 
            RIGHT OUTER JOIN actividad AC 
            INNER JOIN Asignar_tareas_especificas ATE ON (AC.idn_correlativo = ATE.idn_correlativo )
            INNER JOIN Usuario U_1 ON LTRIM(RTRIM(AC.rut_elamp)) = LTRIM(RTRIM(U_1.rut_usuario)) 
            INNER JOIN Usuario U_2 ON LTRIM(RTRIM(ATE.rut_asignado)) = LTRIM(RTRIM(U_2.rut_usuario)) 
            INNER JOIN Area A ON U_2.idn_area = A.idn_area ON 
        													(SQ.id_sub_elemento_qpro = ATE.id_sub_elemento_qpro)
        	WHERE (EQ.id_elemento_QPro = 14) and SQ.id_sub_elemento_qpro <> 140
        		  AND
        		  (convert(datetime, ATE.f_inic,103) between 
        			convert(datetime, @fecha_inicio,103) and convert(datetime, @fecha_fin,103))
        		 AND (ATE.estado = 1)
        		 AND (A.idn_area IN (SELECT idn_area FROM @TMP_AREAS))
        		 AND ((CONVERT(char(10), ATE.fecha_respuesta, 103) <> '01/01/1900') AND (ATE.fecha_respuesta is not null))
        		 AND ((DATEDIFF(D, convert(datetime, ATE.fecha_respuesta, 103), CONVERT(DATETIME, ATE.f_fin, 103))) < 0)
 */
        
        SELECT @no_realizadas = @no_realizadas + 1, @nok_codigos = @nok_codigos + ',''' + CONVERT(VARCHAR, Actividades_Especificas.codigo) + '''', @ok1_total = @ok1_total + 1    			
        FROM Actividades_Especificas 
        INNER JOIN Usuario ON ltrim(rtrim(Actividades_Especificas.asignada_a)) = ltrim(rtrim(Usuario.rut_usuario))
        WHERE  realizado is null AND convert(datetime,convert(char(10),getdate(),103),103) > convert(datetime,convert(char(10),hasta,103),103)
             AND fecha_respuesta is null 
             AND (Usuario.idn_area IN(SELECT idn_area FROM @TMP_AREAS))
             -- AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 31) AND (asignada_por <> '') AND (codigo <> ''); -- 24-04-2019: HC => Se cambia id_elemento_qpro 29 por 31
             AND (id_sub_elemento_qpro <> 140) AND (id_elemento_qpro = 32) AND (asignada_por <> '') AND (codigo <> ''); -- 24-04-2019: HC => Se cambia id_elemento_qpro 31 por 32
--AND ((DATEDIFF(D, convert(datetime, @fecha_actual, 103), convert(datetime, hasta , 103))) < 0)

/*        	FROM Elemento_QPRO EQ
            INNER JOIN Sub_Elemento_Qpro SQ ON (EQ.id_elemento_qpro = SQ.id_elemento_qpro)
            INNER JOIN Clasificacion_Act_Especifica CAE ON (EQ.id_clasificacion_act_especifica = CAE.id_clasificacion_act_especifica) 
            RIGHT OUTER JOIN actividad AC 
            INNER JOIN Asignar_tareas_especificas ATE ON (AC.idn_correlativo = ATE.idn_correlativo )
            INNER JOIN Usuario U_1 ON LTRIM(RTRIM(AC.rut_elamp)) = LTRIM(RTRIM(U_1.rut_usuario)) 
            INNER JOIN Usuario U_2 ON LTRIM(RTRIM(ATE.rut_asignado)) = LTRIM(RTRIM(U_2.rut_usuario)) 
            INNER JOIN Area A ON U_2.idn_area = A.idn_area ON 
        													(SQ.id_sub_elemento_qpro = ATE.id_sub_elemento_qpro)
        	WHERE (EQ.id_elemento_QPro = 14) and SQ.id_sub_elemento_qpro <> 140
        		  AND
        		  (convert(datetime, ATE.f_inic,103) between 
        			convert(datetime, @fecha_inicio,103) and convert(datetime,@fecha_fin,103))
        		 AND (A.idn_area IN (SELECT idn_area FROM @TMP_AREAS))
        		 AND (ATE.estado = 1)
        		 AND ((CONVERT(VARCHAR, ATE.fecha_respuesta, 103) = '01/01/1900') OR (ATE.fecha_respuesta is null))
        		 AND ((DATEDIFF(D, convert(datetime, @fecha_actual, 103), convert(datetime, ATE.f_fin , 103))) < 0)
*/        
                  
        SELECT (@realizadas + @fp) AS ok, @ok_codigos AS ok_codigos, 
              (@atrasadas + @no_realizadas) as nok, @nok_codigos AS nok_codigos,
				@ok1_total as ok1_total;
        
    END TRY
    BEGIN CATCH

        SELECT 0 AS ok, '''''' AS ok_codigos, 
               0 nok,  '''''' AS nok_codigos,
			   0  AS ok1_total;            
    
    END CATCH      
END;
GO

