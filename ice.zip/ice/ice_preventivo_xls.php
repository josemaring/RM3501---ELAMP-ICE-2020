<?php
//Autor: Luis Cruz 
//Fecha: 03-01-2018
//Descripción: Informe ICE preventivo
//Cambios: 
//Proyecto           Fecha        Descripcion
//RM185         01-02-2018        Se agrega opcion para cargar ICE preventivo DCC
//Mejoras Elamp         02-05-2019        Se Modifica programa preventivo 29 a 31 (FY19)

$fechaCreacion = date('d-M-Y');
header("Content-type: application/vnd.ms-excel; name='excel'");
header("Content-Disposition: filename=icePreventivo".$fechaCreacion.".xls");
header("Pragma: no-cache");
header("Expires: 0");

include('../conexiones/conect_elamp.php');
include('config_ice_dcc.php');

$link = conexion();

function calcular_sub_pae($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual, $subelemento)
{        
    $sql = "exec ri_informe_ice_calcular_prog_prev ".$codigo_area.", '".$considera_hijas."', '";
    $sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."',".$subelemento;
    //echo "<br>";       
    $rs = mssql_query($sql);
    $sub_pae_1 = array("ok" => 0, 
                      "ok_codigos" => "", 
                      "nok" => 0, 
                      "nok_codigos" => "", 
                      "%" => 0, 
                      "ok_total" => 0);

    while($rs = mssql_fetch_array($rs))
    {               
        $sub_pae_1 = array("ok" => $rs["ok"], 
                           "ok_codigos" => $rs["ok_codigos"], 
                           "nok" => $rs["nok"], 
                           "nok_codigos" => $rs["nok_codigos"],
                           "%" => 0,
                           "ok_total" => $rs["ok1_total"]
             );
                           
        if(($rs["ok"] > 0) || ($rs["nok"] > 0))
        {
            $sub_pae_1["%"] = number_format(100*$rs["ok"]/($rs["ok"] + $rs["nok"]),1);
            $sub_pae_1["%"] = number_format((100*$rs["ok"])/($rs["ok1_total"]),1);
        }            
    }
    
    $sub_pae = array("1" => $sub_pae_1);
    
    return $sub_pae;         
}
function calcular_sub_pae_dcc($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual, $subelemento)
{        
    $sql = "exec ri_informe_ice_calcular_prog_prev_dcc ".$codigo_area.", '".$considera_hijas."', '";
  $sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."',".$subelemento;
    //echo "<br>";       
    $rs = mssql_query($sql);
    $sub_pae_1 = array("ok" => 0, 
                      "ok_codigos" => "", 
                      "nok" => 0, 
                      "nok_codigos" => "", 
                      "%" => 0, 
                      "ok_total" => 0);

    while($rs = mssql_fetch_array($rs))
    {               
        $sub_pae_1 = array("ok" => $rs["ok"], 
                           "ok_codigos" => $rs["ok_codigos"], 
                           "nok" => $rs["nok"], 
                           "nok_codigos" => $rs["nok_codigos"],
                           "%" => 0,
                           "ok_total" => $rs["ok1_total"]
             );
                           
        if(($rs["ok"] > 0) || ($rs["nok"] > 0))
        {
            $sub_pae_1["%"] = number_format(100*$rs["ok"]/($rs["ok"] + $rs["nok"]),1);
            $sub_pae_1["%"] = number_format((100*$rs["ok"])/($rs["ok1_total"]),1);
        }            
    }
    
    $sub_pae = array("1" => $sub_pae_1);
    
    return $sub_pae;         
}

global $id_programa;

//if($id != '4')
//{
//    $id_programa = 25;
//}else{
  //13-04-2020: HC => Se modifica por programa preventivo 2020
  $id_programa = 32;
//}
$sql = "SELECT TOP (200) id_sub_elemento_qpro, nombre_sub_elemento_qpro,";
$sql .= "id_elemento_qpro, habilitado ";
$sql .= "FROM Sub_Elemento_Qpro WITH (NOLOCK) ";
$sql .= "WHERE (id_elemento_qpro = ".$id_programa.") AND (habilitado = 1) ";
$sql .= "ORDER BY nombre_sub_elemento_qpro";

$rec_sql = mssql_query($sql);
$rec_sql_r = mssql_query($sql);

if($id == 1) $sql_ap = "exec ri_informe_ice_area_informe_principales";
elseif($id == 2) $sql_ap = "exec ri_informe_ice_area_informe_principales_co_fo";
elseif($id == 3) $sql_ap = "exec ri_informe_ice_area_informe_principales_kcc";
elseif($id == 4) $sql_ap = "exec ri_informe_ice_area_informe_principales_dcc";

$rec_areas_principales = mssql_query($sql_ap);
$num_ap = mssql_num_rows($rec_areas_principales);

if($id == 1) $sql_ar = "exec ri_informe_ice_area_informe_resumen";
elseif($id == 2) $sql_ar = "exec ri_informe_ice_area_informe_resumen_co_fo";
elseif($id == 3) $sql_ar = "exec ri_informe_ice_area_informe_resumen_kcc";
elseif($id == 4) $sql_ar = "exec ri_informe_ice_area_informe_resumen_dcc";

$rec_areas_resumen = mssql_query($sql_ar);
$num_ar = mssql_num_rows($rec_areas_resumen);

//03-02-2018: Se obtiene la fecha actual
$sqlf = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
$rs_fecha = mssql_query($sqlf);
$rowf = mssql_fetch_array($rs_fecha);
$fecIni = $rowf["fec"];
$fec = explode("/", $fecIni);
$fecha_inicio = $fec[2].$fec[1].$fec[0];
     
$fecha_actual = date('Y').date('m').date('d');
$fecha_termino = date('Y').date('m').date('d');

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
 
    <title>Elamp. Ingreso de Incidentes</title>
    <meta name="description" content="">
    <meta name="author" content="Patrick Filler, Harvest">
    
    <!-- Place favicon.ico & apple-touch-icon.png in the root of your domain and delete these references -->
    <link rel="shortcut icon" href="/favicon.ico">
    <link rel="apple-touch-icon" href="/apple-touch-icon.png">
 
  </head>
  <body>
    <form method="post" action="" name="frm">
      <input type="hidden" name="especificas" value="">
      <table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#999999">
        <tr>
          <td width="250" rowspan="2" valign="baseline" bgcolor="#CCCCCC" class="textos">Faena</td>
          <td width="250" rowspan="2" valign="baseline" bgcolor="#CCCCCC" class="textos">Responsable</td>
          <?php 
          while($row = mssql_fetch_array($rec_sql)){
          ?>
          <td colspan="4" valign="baseline" bgcolor="#CCCCCC" class="textos">
            <div align="center">
            <?=$row[1]?>
            </div>
          </td>
          <?php 
          }
          ?>
        </tr>
        <tr>
        <?php
        $rec_sql2 = mssql_query($sql);
        while($row = mssql_fetch_array($rec_sql2)){
        ?>
          <td valign="baseline" bgcolor="#CCCCCC" class="textos"><div align="center">OK</div></td>
          <td valign="baseline" bgcolor="#CCCCCC" class="textos"><div align="center">NOK</div></td>
          <td valign="baseline" bgcolor="#CCCCCC" class="textos"><div align="center">%</div></td>
          <td valign="baseline" bgcolor="#FFFF80" class="textos"><div align="center">% Item</div></td>
        <?php 
        }
        ?>
        </tr>
        <?php 
        while($row_ap = mssql_fetch_array($rec_areas_principales)){
          $hijas[] = $row_ap["id"];
          $sql_ah = "exec ri_informe_ice_area_informe_hijas ".$row_ap["id"];
          $rec_sql_ah = mssql_query($sql_ah);
          while($row_ah = mssql_fetch_array($rec_sql_ah)){
            $hijas[] = $row_ah[1];
          }
        ?>
        <tr>
          <td class="textos"><?=$row_ap[2]?></td>
          <td class="textos"><?=ucwords(strtolower($row_ap[3]))?></td>
        <?php 
          $rec_sql2 = mssql_query($sql);
          $tot = 0;
          $numtot = 0;
          while($row = mssql_fetch_array($rec_sql2)){
             //$sqlf = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
             //$rs = mssql_query($sqlf);
             //$rowf = mssql_fetch_array($rs);
             //$fecIni = $rowf["fec"];
             //$fec = explode("/",$fecIni);
             //$fecha_inicio = $fec[2].$fec[1].$fec[0];
      
             //$fecha_actual = date('Y').date('m').date('d');
             //$fecha_termino = date('Y').date('m').date('d');
           if($id != '4')
{
    $t = calcular_sub_pae($row_ap[1], $row_ap[4], $fecha_inicio, $fecha_termino, $fecha_actual, $row[0]);
}else{
  $t = calcular_sub_pae_dcc($row_ap[1], $row_ap[4], $fecha_inicio, $fecha_termino, $fecha_actual, $row[0]);
}

             
        ?>
          <td class="textos" style="cursor:pointer; text-decoration:underline">
            <div align="center">
          <?php foreach($t as $v) echo $v["ok"];?>
            </div>
          </td>
          <td class="textos" style="cursor:pointer; text-decoration:underline">
            <div align="center">
          <?php foreach($t as $v) echo $v["nok"];?>
            </div>
          </td>
          <td class="textos">
            <div align="center"><?php foreach($t as $v) echo $v["%"];?>%</div>
          </td>
          <td bgcolor="#FFFF80" class="textos">
          <div align="center"><?php foreach($t as $v) echo $v["%"];?>%</div>
          </td>
            <?php 
            foreach($t as $v){
             $tot = $tot + $v["%"];
             if($v["%"] <> "0") $numtot++;
            }
          }
  
          unset($hijas);
          $porc = $tot/$numtot;
    
          if($porc < 90)
          {
              $html = "#FF0000";
          }
          else
          {
            if(
    //($porcentaje >= InformeIceModel::$LIMITE_PORCENTAJE) and 
              ($porc < 90+4.5))
                $html = "#FFFF00";
            else $html = "#80FF80";
         }
         ?>
          <td width="418" rowspan="1" align="center" valign="middle" bgcolor="<?=$html?>"><?=number_format($tot/$numtot,1)?>%</td>
        </tr>
      <? }?>
      </table>
      <p><br></p>
      <table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#999999">
        <tr>
          <td width="250" rowspan="2" valign="baseline" bgcolor="#CCCCCC" class="textos">Faena</td>
          <td width="250" rowspan="2" valign="baseline" bgcolor="#CCCCCC" class="textos">Responsable</td>
          <?php 
          while($row = mssql_fetch_array($rec_sql_r)){?>
          <td colspan="4" valign="baseline" bgcolor="#CCCCCC" class="textos">
              <div align="center"><?=$row[1]?></div>
          </td>
          <? }?>
        </tr>
        <tr>
        <?php
          $rec_sql2 = mssql_query($sql);
          while($row = mssql_fetch_array($rec_sql2)){?>
          <td valign="baseline" bgcolor="#CCCCCC" class="textos"><div align="center">OK</div></td>
          <td valign="baseline" bgcolor="#CCCCCC" class="textos"><div align="center">NOK</div></td>
          <td valign="baseline" bgcolor="#CCCCCC" class="textos"><div align="center">%</div></td>
          <td valign="baseline" bgcolor="#FFFF80" class="textos"><div align="center">% Item</div></td>
          <? }?>
        </tr>
        <?php 
        while($row_ap = mssql_fetch_array($rec_areas_resumen)){
           $hijas[] = $row_ap["id"];
           $sql_ah = "exec ri_informe_ice_area_informe_hijas ".$row_ap["id"];
           $rec_sql_ah = mssql_query($sql_ah);
           while($row_ah = mssql_fetch_array($rec_sql_ah)){
             $hijas[] = $row_ah[1];
           }
        ?>
        <tr>
          <td class="textos"><?=$row_ap[2]?></td>
          <td class="textos"><?=ucwords(strtolower($row_ap[3]))?></td>
          <?php 
          $rec_sql2 = mssql_query($sql);
          $tot = 0;
          $numtot = 0;
          while($row = mssql_fetch_array($rec_sql2)){
              //$sqlf = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
              //$rs = mssql_query($sqlf);
              //$rowf = mssql_fetch_array($rs);
              //$fecIni = $rowf["fec"];
              //$fec = explode("/",$fecIni);
              //$fecha_inicio = $fec[2].$fec[1].$fec[0];
              
              //$fecha_actual = date('Y').date('m').date('d');
              //$fecha_termino = date('Y').date('m').date('d');
if($id != '4')
{
    $t = calcular_sub_pae($row_ap[1], $row_ap[4], $fecha_inicio, $fecha_termino, $fecha_actual, $row[0]);
}else{
  $t = calcular_sub_pae_dcc($row_ap[1], $row_ap[4], $fecha_inicio, $fecha_termino, $fecha_actual, $row[0]);
}
              
          ?>
          <td class="textos" style="cursor:pointer; text-decoration:underline">
            <div align="center"><? foreach($t as $v) echo $v["ok"];?></div>
          </td>
          <td class="textos" style="cursor:pointer; text-decoration:underline">
            <div align="center"><? foreach($t as $v) echo $v["nok"];?></div>
          </td>
          <td class="textos">
            <div align="center"><? foreach($t as $v) echo $v["%"];?>%</div>
          </td>
          <td bgcolor="#FFFF80" class="textos">
          <div align="center"><? foreach($t as $v) echo $v["%"];?>%</div>
          </td>
          <?php 
          foreach($t as $v){
            $tot = $tot + $v["%"];
            if($v["%"] <> "0") $numtot++;
          }
        }

        unset($hijas);
        $porc = $tot/$numtot;
    
        if($porc < 90)
        {
            $html = "#FF0000";
        }
        else
        {
          if($porc < 90+4.5){
              $html = "#FFFF00";
          }
          else{ 
            $html = "#80FF80";
          }
       }
  ?>
          <td rowspan="1" align="center" valign="middle" bgcolor="<?=$html?>"><?=number_format($tot/$numtot,1)?>%</td>
        </tr>
      <? }?>
      </table>
    </form>
  </body>
</html>