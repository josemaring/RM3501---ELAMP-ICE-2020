<?php
define("TIME_PERIODS_PLURAL_SINGULAR", "semanas:semana,a�os:a�o,dias:dia,hrs:hr, : ,mnts:mnt,segs:seg");
DEFINE("TIME_LEFT_STRING_TPL", " #num# #period#");
  
class Fecha{
    var $strDia = "";         //Identifica el Dia de la Fecha
    var $strMes = "";         //Identifica el Mes de la Fecha
    var $strAno = "";         //Identifica el Año de la Fecha
    var $strFDMA = "";        //Identifica la Fecha con formato dd-mm-aaaa
    var $strFAMD = "";        //Identifica la Fecha con formato aaaa-mm-dd
    var $Dia = 1;             //Identifica el Dia Numerico de la Fecha
    var $Mes = 1;             //Identifica el Mes Numerico de la Fecha
    var $Ano = 2000;          //Identifica el Año Numerico de la Fecha
    var $strHora = 0;         //Identifica la Hora de la Fecha
    var $strMinutos = 0;      //Identifica los Minutos de la Fecha
    var $strSegundos = 0;     //Identifica los segundos de la Fecha
    var $DSemana = 0;         //Identifica el numero del dia de la semana
    var $strDSemana = "";     //Identifica el nombre del dia de la semana
    var $meses;               //Identifica un arreglo con los nombres de los meses
    var $dias;                //Identifica un arreglo con los nombres de los dias
    
    //Constructor de la Clase, se inicializan variables
    function Fecha()
    { 
        $this->meses = array("01" => "Enero", "02" => "Febrero",
                             "03" => "Marzo", "04" => "Abril",
                             "05" => "Mayo", "06" => "Junio",
                             "07" => "Julio", "08" =>  "Agosto",
                             "09" =>  "Septiembre", "10" => "Octubre",
                             "11" => "Noviembre", "12" => "Diciembre");
     
        $this->dias = array("0" => "Domingo", "1" => "Lunes",
                            "2" => "Martes", "3" => "Miercoles",
                            "4" => "Jueves", "5" => "Viernes",
                            "6" => "Sabado");            
    } 
    
    //Se asigna el valor de la variable Dia
    function setDia($dia)
    {
        if(strlen($dia) == 1)
        { 
            $this->strDia = "0".$dia;
        }
        else
        {
            $this->strDia = $dia;
        }
    }
    
    //Se asigna el valor de la variable Mes
    function setMes($mes)
    {
        if(strlen($mes) == 1)
        { 
            $this->strMes = "0".$mes;
        }
        else
        {
            $this->strMes = $mes;
        } 
    }    
    
    //Se asigna el valor de la variable Año
    function setAno($ano)
    {
        $this->strAno = $ano;
    }

    //Se asigna el valor de la variable Hora
    function setHora($hora)
    {
        if(strlen($hora) == 1)
        { 
            $this->strHora = "0".$hora;
        }
        else
        {
            $this->strHora = $hora;
        }
    }
    
    //Se asigna el valor de la variable Minutos
    function setMinutos($min)
    {
        if(strlen($min) == 1)
        { 
            $this->strMinutos = "0".$min;
        }
        else
        {
            $this->strMinutos = $min;
        } 
    }    
    
    //Se asigna el valor de la variable Segundos
    function setSegundos($seg)
    {
        if(strlen($seg) == 1)
        { 
            $this->strSegundos = "0".$seg;
        }
        else
        {
            $this->strSegundos = $seg;
        } 
    }
    
    //Se asigna el valor de la variable Dia semana
    function setDSemana($dia)
    {
        $this->DSemana = $dia;      
        $this->strDSemana = $this->dias[$dia];
    }            
    
    //Se asigna el valor de la variable Fecha con formato dd-mm-aaaa
    function setFDMA($fecha)
    {
        $this->strFDMA = $fecha;
    }

    //Se asigna el valor de la variable Fecha con formato aaaa-mm-dd
    function setFAMD($fecha)
    {
        $this->strFAMD = $fecha;
    }

    //Se obtiene el valor de la variable Dia
    function getDia()
    {
        return  $this->strDia;
    }
    
    //Se obtiene el valor de la variable Mes
    function getMes()
    {
        return $this->strMes;
    }    

    //Se obtiene el valor de la variable Nombre Mes
    function getNMes()
    {
        return $this->meses[$this->getMes()];
    }    
        
    //Se obtiene el valor de la variable Año
    function getAno()
    {
        return $this->strAno;
    }

    //Se obtiene el valor de la variable Hora
    function getHora()
    {
        return  $this->strHora;
    }
    
    //Se obtiene el valor de la variable Minutos
    function getMinutos()
    {
        return $this->strMinutos;
    }    
    
    //Se obtiene el valor de la variable Segundos
    function getSegundos()
    {
        return $this->strSegundos;
    }

    //Se obtiene el valor de la variable Nmero dia semana
    function getNDSemana(){
        return $this->DSemana;
    }

    //Se obtiene el valor de la variable Nombre dia semana
    function getDSemana()
    {
        return $this->strDSemana;
    }
                
    //Se obtiene el valor de la variable Fecha con formato dd-mm-aaaa
    function getFDMA()
    {
        return $this->strFDMA;
    }

    //Se obtiene el valor de la variable Fecha con formato aaaa-mm-dd
    function getFAMD()
    {
        return $this->strFAMD;
    }
                
    //Se obtiene la Fecha actual
    function fechaActual($valor = "")
    {
        if($valor != "")
        {
            $fecha = getDate($valor);
        }
        else
        {
            $fecha = getDate();
        }
        
        $this->setDia($fecha["mday"]);
        $this->setMes($fecha["mon"]);
        $this->setAno($fecha["year"]);
        $this->setHora($fecha["hours"]);
        $this->setMinutos($fecha["minutes"]);
        $this->setSegundos($fecha["seconds"]);      
        $this->setDSemana($fecha["wday"]);      
    }
    
    //Se obtiene la Fecha con Formato dd-mm--aaaa
    function getDMA()
    {
        $this->fechaActual();
             
        $this->setFDMA($this->getDia()."-".$this->getMes()."-".$this->getAno());
      
        return $this->getFDMA();
    }

    //Se obtiene la Fecha con formato aaaa-mm-dd
    function getAMD(){
        $this->fechaActual();
      
        $this->setFAMD($this->getAno()."-".$this->getMes()."-".$this->getDia());
      
        return $this->getFAMD();
    }

    //Se obtiene la Hora actual con formato hh:mm
    function horaActual()
    {
        $this->fechaActual();
      
        $hora = $this->getHora().":".$this->getMinutos();
        
        return $hora;
    }
    
    //Se obtiene la Fecha con formato "dd-mm-aaaa hh:mm:ss"
    function getFHDMA()
    {
        $this->fechaActual();
      
        $strR = $this->getDia()."-".$this->getMes()."-".$this->getAno();
        $strR .= " ".$this->getHora().":".$this->getMinutos().":".$this->getSegundos();
        $this->setFDMA($strR);
      
        return $this->getFDMA();
    }

    //Se obtiene la Fecha con formato "aaaa-mm-dd hh:mm:ss"
    function getFHAMD()
    {
        $this->fechaActual();
      
        $strR = $this->getAno()."-".$this->getMes()."-".$this->getDia();
        $strR .= " ".$this->getHora().":".$this->getMinutos().":".$this->getSegundos();
        $this->setFAMD($strR);
      
        return $this->getFAMD();
    }
    
    //Se obtiene la Fecha cn formato "dia, dia mes año"
    function getFElegante()
    {
        $this->fechaActual();
      
        $strR = $this->getDSemana()." ".$this->getDia()." de ".$this->getNMes();
        $strR .= " de ".$this->getAno();
      
        return $strR;
    }

    //Se obtiene la Fecha cn formato "dia dia mes a�o"
    function fechaElegante($fecha, $formato)
    {
        $fecha = split("-", $fecha);
        
        if($formato == "dma")
        {
            $fecha = $this->fechaActual(mktime(0, 0, 0, $fecha[1], $fecha[0], $fecha[2]));        
        }
        else if($formato == "amd")
        {
            $fecha = $this->fechaActual(mktime(0, 0, 0, $fecha[1], $fecha[2], $fecha[0]));            
        }
        
        $strR = $this->getDSemana()." ".$this->getDia()." de ".$this->getNMes();
        $strR .= " de ".$this->getAno();
      
        return $strR;
    }
        
    //Se convierte la fecha a formato dd-mm-aaaa
    function formatoDMA($fecha)
    {
        list( $ano, $mes, $dia ) = split("[/.-]", $fecha);

        $this->setDia($dia);
        $this->setMes($mes);
        $this->setAno($ano);
      
        $this->setFDMA($this->getDia()."-".$this->getMes()."-".$this->getAno());
      
        return $this->getFDMA();
    }
      
    //Se convierte la fecha a formato aaaa-mm-dd
    function formatoAMD($fecha)
    {
        if($fecha != "")
        {
            list($dia, $mes, $ano ) = split("[/.-]", $fecha);
          
            $this->setDia($dia);
            $this->setMes($mes);
            $this->setAno($ano);
          
            $this->setFAMD($this->getAno()."-".$this->getMes()."-".$this->getDia());
          
            return $this->getFAMD();
        }
        else
        {
            return "";
        }
    }

    //Se convierte la fecha a formato dd-mm-aaaa hh:mm:ss
    function formatoFHDMA($fh)
    {
        list($fecha, $hora) = split(" ", $fh);
        list($ano, $mes, $dia) = split("[/.-]", $fecha);
        list($hr, $min, $seg) = split(":", $hora);
      
        $this->setDia($dia);
        $this->setMes($mes);
        $this->setAno($ano);
        $this->setHora($hr);
        $this->setMinutos($min);
        $this->setSegundos($seg);
        $this->setFDMA($this->getDia()."-".$this->getMes()."-".$this->getAno());
           
        return $this->getFDMA()." ".$this->getHora().":".$this->getMinutos().":".$this->getSegundos();
    }

    //Se convierte la fecha a formato aaaa-mm-dd hh:mm:ss
    function formatoFHAMD($fh)
    {
        list($fecha, $hora) = split(" ", $fh);
        list($dia, $mes, $ano) = split("[/.-]", $fecha);
        list($hr, $min, $seg) = split(":", $hora);
      
        $this->setDia($dia);
        $this->setMes($mes);
        $this->setAno($ano);
        $this->setHora($hr);
        $this->setMinutos($min);
        $this->setSegundos($seg);
        $this->setFAMD($this->getAno()."-".$this->getMes()."-".$this->getDia());
           
        return $this->getFAMD()." ".$this->getHora().":".$this->getMinutos().":".$this->getSegundos();    
    }
    
    //Se obtiene el numero de dias de un mes
    function diasMes($mes)
    {    
        if(strlen($mes) == 1){
            $mes = "0".$mes;
        }
      
        $dias = array("01" => "31", "02" => "28", "03" => "31",
                      "04" => "30", "05" => "31", "06" => "30",
                      "07" => "31", "08" => "31", "09" => "30",
                      "10" => "31", "11" => "30", "12" => "31",
                      );
      
        return $dias[$mes];
    }
         
    //Se obtiene la Fecha de inicio de cualquier mes
    function diaInicio($mes, $ano)
    {
        $this->fechaActual();
        if($mes == ""){
            $mes = $this->getMes();
        }
        if($ano == ""){
            $ano = $this->getAno();
        }
      
        return $ano."-".$mes."-"."01";
    }   

    //Se obtiene la Fecha de inicio de cualquier mes
    function diaTermino($mes, $ano)
    {
        $this->fechaActual();
        if($mes == ""){
            $mes = $this->getMes();
        }
        if($ano == ""){
            $ano = $this->getAno();
        }         
      
        $dia = $this->diasMes($mes);
        
        return $ano."-".$mes."-".$dia;
    }   
    
    //Se verifica si una Fecha 1, es Mayor que Fecha 2
    function esMayor($fecha1, $fecha2)
    {            
        return 0;
    }
    
    //Se obtiene el dia de la semana
    function diaSemana()
    {
        $dia = date("w");
        
        switch($dia){
            case 0:
                $diaSemana = 7;
                break;
            case 1:
                $diaSemana = 1;
                break;
            case 2:
                $diaSemana = 2;
                break;
            case 3:
                $diaSemana = 3;
                break;
            case 4:
                $diaSemana = 4;
                break;
            case 5:
                $diaSemana = 5;
                break;
            case 6:
                $diaSemana = 6;
                break;                
        }
        
        return $diaSemana;
    }
    
    //Se obtiene una Fecha de busqueda
    function fechaBusqueda($tipo = "")
    {
        if(($tipo != "") && ($tipo != "-1"))
        {
            $fecha = "";
            switch($tipo)
            {
                case 0: //Ultima semana
                    $fecha = $this->restarTiempo(0, 0, 7);
                    break;
                case 1: //Ultima quincena
                    $fecha = $this->restarTiempo(0, 0, 15);
                    break;
                case 2: //Ultimo mes
                    $fecha = $this->restarTiempo(0, 1, 0);
                    break;
                case 3: //Ultima Semestre
                    $fecha = $this->restarTiempo(0, 6, 0);
                    break;
                case 4: //Ultimo Ano
                    $fecha = $this->restarTiempo(1, 0, 0);
                    break;
            }
            
            return $fecha;
        }
        
        return "";
    }
    
    //Se suman dias, meses y a�os a una fecha
    function sumarTiempo($anos = 0, $meses = 0, $dias = 0) 
    {
        $fecha = "";        
        $array_date = explode("-", $this->getDMA());
        $fecha = Date("Y-m-d", mktime(0, 0, 0, $array_date[1] + $meses, $array_date[0] + $dias, $array_date[2] + $anos));
        
        return $fecha;
    }
    
    //Se restan dias, meses y a�os a una fecha
    function restarTiempo($anos = 0, $meses = 0, $dias = 0) 
    {
        $fecha = "";
        
        $array_date = explode("-", $this->getDMA());
        $fecha = Date("Y-m-d", mktime(0, 0, 0, $array_date[1] - $meses, $array_date[0] - $dias, $array_date[2] - $anos));
        
        return $fecha;
    }
    
    //Se obtiene el tiempo entre dos fecha
    function tiempo($inicio, $fin)
    {
        if($inicio == $fin)
        {
            return 0;
        }
        
        $fecha1 = strtotime($inicio);
        $fecha2 = strtotime($fin);
        
        $segundos = $fecha2 - $fecha1;
        $arreglo = $this->time_left(time() - $segundos);
        
        return $arreglo;
    }
    
    function time_left($time)
    {
        if (($now = time()) <= $time) return false;

        $timeRanges = array('a�os' => 365*60*60*24,/* 'weeks' => 60*60*24*7, */ 'dias' => 60*60*24, 'hrs' => 60*60, 'mnts' => 60, 'segs' => 1);

        $secondsLeft = $now-$time;

        // prepare ranges
        $outRanges = array();
        foreach ($timeRanges as $period => $sec)
        {
            if ($secondsLeft/$sec >= 1)
            {
                $outRanges[$period] =  floor($secondsLeft/$sec);
                $secondsLeft -= ($outRanges[$period] * $sec);
            }
        }

        // playing with TIME_PERIODS_PLURAL_SINGULAR
        $periodsEx = explode(",", TIME_PERIODS_PLURAL_SINGULAR);
        $periodsAr = array();
        foreach ($periodsEx as $periods)
        {
            $ex  = explode(":", $periods);
            $periodsAr[$ex[0]] = array('plural' => $ex[0], 'singular' => $ex[1]);
        }

        // string out
        $outString = "";
        $outStringAr = array();
        foreach ($outRanges as $period => $num)
        {
            $per = $periodsAr[$period]['plural'];
            if ($num == 1)  $per = $periodsAr[$period]['singular'];

            $outString .= $outStringAr[$period] = str_replace(array("#num#", "#period#"), array($num, $per), TIME_LEFT_STRING_TPL);
        }
            
        //return array('timeRanges' => $outRanges, 'leftStringAr' => $outStringAr, 'leftString' => $outString);
        return $outString;
    }    
    
    //Se obtiene la fecha actual para ingresarla en la base de datos
    function getFechaSQL()    
    {
        global $__DB;
        if(($__DB["formato_fecha"] == "dd-mm-aaaa") || ($__DB["formato_fecha"] == "dd/mm/aaaa"))
        {
            return $this->getFHDMA();
        }
        else if(($__DB["formato_fecha"] == "aaaa-mm-dd") || ($__DB["formato_fecha"] == "aaaa/mm/dd"))
        {
            return $this->getFHAMD();
        }
        else
        {
            $this->fechaActual();
            $fecha = $this->getAno();
            $fecha .= $this->getMes();
            $fecha .= $this->getDia();
            return $fecha." ".$this->horaActual();
        }
    }
    
    //Se formatea la fecha de acuerdo a lo que recibe SQL
    function formatearSQL($fecha)
    {
        global $__DB;
        if(($__DB["validacion_fecha"] == "dd-mm-aaaa") || ($__DB["validacion_fecha"] == "dd/mm/aaaa"))
        {
            if($__DB["formato_fecha"] == "dd-mm-aaaa")
            {
                return $fecha;
            }
            else if($__DB["formato_fecha"] == "aaaa-mm-dd")
            {
                $data = explode("-", $fecha);
                
                return $data[2]."-".$data[1]."-".$data[0];
            }
        }
        else
        {
            return $fecha;
        }
    }
    
    //Se obtiene la fecha a�omesdia
    function amdNumerico()
    {
        $fecha = $this->getAMD();
        
        $fecha = str_replace("-", "", $fecha);
        $fecha = str_replace("/", "", $fecha);
        
        return $fecha;
    }
    
    //Se obtiene el inicio Fiscal Year
    function fiscalYear()
    {
        $hoy = date("Y-m-d");
        //$hoy = "2020-03-02";
        
        $anio = date("Y");
        
        $fiscal_year = $anio."-04-01";
        $inicio_anio = $anio."-01-01";
        $limite = strtotime($fiscal_year);
        $actualidad = strtotime($hoy);
        
        $anio_fiscal = $anio;
        if(($actualidad > strtotime($inicio_anio)) && ($actualidad < $limite))
        {
          $anio_fiscal = $anio - 1;
        }
        
        $fiscal_year = $anio_fiscal."0401";
        return $fiscal_year;
    }
}
?>