<?php
//Clase que controla los calculos y datos asociados al informe ice
class InformeIceModel extends Model
{
    public static $MODULO = "informe_ice";

    var $PESOS = array("ctp_stp"        => array("peso_item" => 35, "pesos_subitems" => array("1" => 20, "2" => 70, "3" => 10)), 
                       "resto"          => array("peso_item" => 10, "pesos_subitems" => array("1" => 20, "2" => 70, "3" => 10)), 
                       "sugerencias"    => array("peso_item" => 5,  "pesos_subitems" => array("1" => 30, "2" => 70)), 
                       "sub_pae"        => array("peso_item" => 40, "pesos_subitems" => array("1" => 100)),
					   "nc"          => array("peso_item" => 10, "pesos_subitems" => array("1" => 20, "2" => 70, "3" => 10)));    
     
    var $title = array("incidentes" => array("name" => ""),
                       "ctp_stp"    => array("name" => "ACCIDENTES CTP + STP (12 meses flotantes)", 
                                             "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                      "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)", 
                                                      "Por verificar y cerrar <br />(10 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "resto"      => array("name" => "RESTO DE INCIDENTES + NO CONFORMIDADES + TRANSGRESIONES (12 meses flotantes)", 
                                             "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                    "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)",
                                                    "Por verificar y cerrar <br />(10 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "sugerencias" => array("name" => "IDEAS DE MEJORA + TRATAMIENTO DE ACCIONES Y CONDICIONES SUBESTANDARES (12 meses flotantes)", 
                                             "indice" => array("Por revisar <br />(30 %)",
                                                          "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "sub_pae" => array("name" => "ACTIVIDADES DEL PROGRAMA PREVENTIVO FY20 (Se mide A&ntilde;o fiscal al d&iacute;a)",
                                          "indice" => array("Actividades programa preventivo"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido"),
						/*"nc" => array("name" => "NC Auditor�a 2015",
                                          "indice" => array( 
                                                      "En implementaci�n del plan de acci�n <br />(70 %)", 
                                                      ),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido")										  
										  );*/
						"nc" => array("name" => "NC Auditor&iacute;a 2017",
                                          "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                      "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)", 
                                                      "Por verificar y cerrar <br />(10 %)"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido")										  
										  );
               
    public static $LIMITE_PORCENTAJE = 90;
       
	function InformeIceModel() 
    {
		parent::Model();
        $this->MODULO_MODEL = InformeIceModel::$MODULO;
    }
	
    //Se obtiene el arreglo de titulos del informe
    function getTitulos()
    {
        return $this->title;
    }
    
    //Se obtiene el arbol de areas completo
    function arbol_areas()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
    
	//CONSTRUCCION Y FORESTAL
	
	    function arbol_areas_co_fo()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_co_fo";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_co_fo ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_co_fo";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	//DCC
	
	    function arbol_areas_dcc()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_dcc";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_dcc ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_dcc";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
    //14-05-2019: RH, se agrega para nuevo ice
	  function arbol_areas_drs()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_drs";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_drs ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_drs";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	//KCCA
	
	    function arbol_areas_kcca()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_kcca";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_kcca ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_kcca";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
    //Se calculan los valores CTP + STP
    function calcular_ctp_stp($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual, $nuevas)
    {
		if($nuevas == 0) $fecha_inicio = "20151223";
		//else
		
        $sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
		$sql = "exec ri_informe_ice_calcular_ctp_stp ".$codigo_area.", '".$considera_hijas."', '";
        
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $ctp_stp_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $ctp_stp_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $ctp_stp_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $ctp_stp_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $ctp_stp_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]);
            $ctp_stp_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]);
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $ctp_stp_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$ctp_stp_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $ctp_stp_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$ctp_stp_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $ctp_stp_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$ctp_stp_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                                    
        }
        
        $ctp_stp = array("1" => $ctp_stp_1,
                         "2" => $ctp_stp_2,
                         "3" => $ctp_stp_3);
        
        return $ctp_stp;                        
    }
    
    //Se calculan los valores RESTO
    function calcular_resto($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {
		if($nuevas == 0) $fecha_inicio = "20151223";
		
		$sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
        $sql = "exec ri_informe_ice_calcular_resto ".$codigo_area.", '".$considera_hijas."', '";
        //echo 
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $resto_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $resto_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $resto_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $resto_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
//			print_r($resto_1;
            $resto_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]
							   );
            $resto_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]
							   );           
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $resto_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$resto_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $resto_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$resto_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $resto_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$resto_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                        
        }
        
        $resto = array("1" => $resto_1,
                       "2" => $resto_2,
                       "3" => $resto_3);
        
        return $resto;
    }
        
    //Se calculan los valores SUGERENCIAS
    function calcular_sugerencias($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {
		if($nuevas == 0) $fecha_inicio = "20151223";
		
		$sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
        $sql = "exec ri_informe_ice_calcular_sugerencias ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
            
        $rs = $this->select($sql);
        $sugerencias_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $sugerencias_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);        
        if(!$rs->EOF)
        {               
            $sugerencias_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $sugerencias_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]
							   );
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $sugerencias_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$sugerencias_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
                        
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $sugerencias_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$sugerencias_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }                                    
        }
        
        $sugerencias = array("1" => $sugerencias_1,
                             "2" => $sugerencias_2);
        
        return $sugerencias;               
    }
        
    //Se calculan los valores 
    function calcular_sub_pae($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		//$fecha_inicio = "20130401";
		
        $sql = "exec ri_informe_ice_calcular_sub_pae ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
                    
        $rs = $this->select($sql);
        $sub_pae_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $sub_pae_1 = array("ok" => $rs->fields["ok"], 
                               "ok_codigos" => $rs->fields["ok_codigos"], 
                               "nok" => $rs->fields["nok"], 
                               "nok_codigos" => $rs->fields["nok_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
                               
            if(($rs->fields["ok"] > 0) || ($rs->fields["nok"] > 0))
            {
                $sub_pae_1["%"] = number_format(100*$rs->fields["ok"]/($rs->fields["ok"] + $rs->fields["nok"]),1);
				$sub_pae_1["%"] = number_format((100*$rs->fields["ok"])/($rs->fields["ok1_total"]),1);
            }            
        }
        
        $sub_pae = array("1" => $sub_pae_1);
        
        return $sub_pae;         
    }
    
    //Se calculan los valores 
    function calcular_ncf($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		if($nuevas == 0) $fecha_inicio = "20151223";
		//else
        $sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
		$sql = "exec ri_informe_ice_calcular_nc2 ".$codigo_area.", '".$considera_hijas."', '";
        
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $ctp_stp_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $ctp_stp_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $ctp_stp_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $ctp_stp_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $ctp_stp_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]);
            $ctp_stp_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]);
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $nc_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$nc_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $nc_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$nc_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $nc_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$nc_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }              
			
			                      
        }
        
        $nc = array("1" => $nc_1,
                         "2" => $nc_2,
                         "3" => $nc_3);
        
        return $nc;     
    }
	
    function calcular_nc($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		if($nuevas == 0) $fecha_inicio = "20151223";
		//else
		$sql = "select convert(char(10),dateadd(year,-1,getdate()),103) as fec";
		$rs = $this->select($sql);
		if(!$rs->EOF)
        {
			$fecIni = $rs->fields["fec"];
		}
		$fec = explode("/",$fecIni);
		
		$fecha_inicio = "20070101";
		$fecha_inicio = $fec[2].$fec[1].$fec[0];
		
		$sql = "exec ri_informe_ice_calcular_nc2 ".$codigo_area.", '".$considera_hijas."', '";
        
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $ctp_stp_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $ctp_stp_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $ctp_stp_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $ctp_stp_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $ctp_stp_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]);
            $ctp_stp_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]);
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $ctp_stp_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$ctp_stp_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $ctp_stp_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$ctp_stp_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $ctp_stp_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$ctp_stp_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                                    
        }
        
        $nc = array("1" => $ctp_stp_1,
		
                         "2" => $ctp_stp_2,
                         "3" => $ctp_stp_3);
        
        return $nc;           
    }
	
    //Se realiza el calculo de % final
    function calcular_porcentaje_area($valores)
    {
        $valor = 0;
        $valor = ($valores["ctp_stp_1"] + $valores["ctp_stp_2"] + $valores["ctp_stp_3"])/3 * $this->PESOS["ctp_stp"];
        $valor += ($valores["resto_1"] + $valores["resto_2"] + $valores["resto_3"]) * $this->PESOS["resto"];
        $valor += ($valores["sugerencias_1"] + $valores["sugerencias_2"]) * $this->PESOS["sugerencias"];
        $valor += ($valores["sub_pae"]) * $this->PESOS["sub_pae"];
		$valor += ($valores["nc"]) * $this->PESOS["nc"];
        
        return $valor;
    }
    
    //Se realiza el calculo de todos los indices
    function calculo_indices($codigo_area, $considera_hijas = "1",$fecha_desde,$fecha_hasta)
    {
        $fechas = $this->rango_fechas_busqueda();
                
        $indices = array();
        $porcentaje = 0;
		
		$nuevas = 0;
		if($fecha_desde<>'' and $fecha_hasta<>''){
			$fechas["fecha_inicio"] = $fecha_desde;
			$fechas["fecha_fin"] = $fecha_hasta;
			$nuevas = 1;	
		}
		
		//if($fecha_hasta<>'') $fechas["fecha_fin"] = $fecha_hasta;
		
		//echo $fechas["fecha_inicio"]." ".$fechas["fecha_fin"];
		$ctp_stp = $this->calcular_ctp_stp($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);

        $indices["ctp_stp"]["1"]["ok"] = $ctp_stp["1"]["ok"];
        $indices["ctp_stp"]["1"]["ok_codigos"] = $ctp_stp["1"]["ok_codigos"];
        $indices["ctp_stp"]["1"]["nok"] = $ctp_stp["1"]["nok"];
        $indices["ctp_stp"]["1"]["nok_codigos"] = $ctp_stp["1"]["nok_codigos"];        
        $indices["ctp_stp"]["1"]["%"] = $ctp_stp["1"]["%"];
		$indices["ctp_stp"]["1"]["ok_total"] = $ctp_stp["1"]["ok_total"];
        
        $indices["ctp_stp"]["2"]["ok"] = $ctp_stp["2"]["ok"];
        $indices["ctp_stp"]["2"]["ok_codigos"] = $ctp_stp["2"]["ok_codigos"];
        $indices["ctp_stp"]["2"]["nok"] = $ctp_stp["2"]["nok"];
        $indices["ctp_stp"]["2"]["nok_codigos"] = $ctp_stp["2"]["nok_codigos"];
        $indices["ctp_stp"]["2"]["%"] = $ctp_stp["2"]["%"];
		$indices["ctp_stp"]["2"]["ok_total"] = $ctp_stp["2"]["ok_total"];
        
        $indices["ctp_stp"]["3"]["ok"] = $ctp_stp["3"]["ok"];
        $indices["ctp_stp"]["3"]["ok_codigos"] = $ctp_stp["3"]["ok_codigos"];
        $indices["ctp_stp"]["3"]["nok"] = $ctp_stp["3"]["nok"];
        $indices["ctp_stp"]["3"]["nok_codigos"] = $ctp_stp["3"]["nok_codigos"];
        $indices["ctp_stp"]["3"]["%"] = $ctp_stp["3"]["%"];
		$indices["ctp_stp"]["3"]["ok_total"] = $ctp_stp["3"]["ok_total"];
        
        $resto = $this->calcular_resto($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);

        $indices["resto"]["1"]["ok"] = $resto["1"]["ok"];
        $indices["resto"]["1"]["ok_codigos"] = $resto["1"]["ok_codigos"]; 
        $indices["resto"]["1"]["nok"] = $resto["1"]["nok"];
        $indices["resto"]["1"]["nok_codigos"] = $resto["1"]["nok_codigos"];
        $indices["resto"]["1"]["%"] = $resto["1"]["%"];
		$indices["resto"]["1"]["ok_total"] = $resto["1"]["ok_total"];
        
        $indices["resto"]["2"]["ok"] = $resto["2"]["ok"];
        $indices["resto"]["2"]["ok_codigos"] = $resto["2"]["ok_codigos"];
        $indices["resto"]["2"]["nok"] = $resto["2"]["nok"];
        $indices["resto"]["2"]["nok_codigos"] = $resto["2"]["nok_codigos"];
        $indices["resto"]["2"]["%"] = $resto["2"]["%"];
		$indices["resto"]["2"]["ok_total"] = $resto["2"]["ok_total"];
        
        $indices["resto"]["3"]["ok"] = $resto["3"]["ok"];
        $indices["resto"]["3"]["ok_codigos"] = $resto["3"]["ok_codigos"];
        $indices["resto"]["3"]["nok"] = $resto["3"]["nok"];
        $indices["resto"]["3"]["nok_codigos"] = $resto["3"]["nok_codigos"];
        $indices["resto"]["3"]["%"] = $resto["3"]["%"];
		$indices["resto"]["3"]["ok_total"] = $resto["3"]["ok_total"];
        
        $sugerencias = $this->calcular_sugerencias($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
        
        $indices["sugerencias"]["1"]["ok"] = $sugerencias["1"]["ok"];
        $indices["sugerencias"]["1"]["ok_codigos"] = $sugerencias["1"]["ok_codigos"];
        $indices["sugerencias"]["1"]["nok"] = $sugerencias["1"]["nok"];
        $indices["sugerencias"]["1"]["nok_codigos"] = $sugerencias["1"]["nok_codigos"];
        $indices["sugerencias"]["1"]["%"] = $sugerencias["1"]["%"];
		$indices["sugerencias"]["1"]["ok_total"] = $sugerencias["1"]["ok_total"];
        
        $indices["sugerencias"]["2"]["ok"] = $sugerencias["2"]["ok"];
        $indices["sugerencias"]["2"]["ok_codigos"] = $sugerencias["2"]["ok_codigos"];
        $indices["sugerencias"]["2"]["nok"] = $sugerencias["2"]["nok"];
        $indices["sugerencias"]["2"]["nok_codigos"] = $sugerencias["2"]["nok_codigos"];
        $indices["sugerencias"]["2"]["%"] = $sugerencias["2"]["%"];
		$indices["sugerencias"]["2"]["ok_total"] = $sugerencias["2"]["ok_total"];
                        
        $sub_pae = $this->calcular_sub_pae($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
        
        $indices["sub_pae"]["1"]["ok"] = $sub_pae["1"]["ok"];
        $indices["sub_pae"]["1"]["ok_codigos"] = $sub_pae["1"]["ok_codigos"];
        $indices["sub_pae"]["1"]["nok"] = $sub_pae["1"]["nok"];
        $indices["sub_pae"]["1"]["nok_codigos"] = $sub_pae["1"]["nok_codigos"];
        $indices["sub_pae"]["1"]["%"] = $sub_pae["1"]["%"];
		$indices["sub_pae"]["1"]["ok_total"] = $sub_pae["1"]["ok_total"];

		$nc = $this->calcular_nc($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
		//print_r($nc);
		
        $indices["nc"]["1"]["ok"] = $nc["1"]["ok"];
        $indices["nc"]["1"]["ok_codigos"] = $nc["1"]["ok_codigos"];
        $indices["nc"]["1"]["nok"] = $nc["1"]["nok"];
        $indices["nc"]["1"]["nok_codigos"] = $nc["1"]["nok_codigos"];        
        $indices["nc"]["1"]["%"] = $nc["1"]["%"];
		$indices["nc"]["1"]["ok_total"] = $nc["1"]["ok_total"];
        
        $indices["nc"]["2"]["ok"] = $nc["2"]["ok"];
        $indices["nc"]["2"]["ok_codigos"] = $nc["2"]["ok_codigos"];
        $indices["nc"]["2"]["nok"] = $nc["2"]["nok"];
        $indices["nc"]["2"]["nok_codigos"] = $nc["2"]["nok_codigos"];
        $indices["nc"]["2"]["%"] = $nc["2"]["%"];
		$indices["nc"]["2"]["ok_total"] = $nc["2"]["ok_total"];
        
        $indices["nc"]["3"]["ok"] = $nc["3"]["ok"];
        $indices["nc"]["3"]["ok_codigos"] = $nc["3"]["ok_codigos"];
        $indices["nc"]["3"]["nok"] = $nc["3"]["nok"];
        $indices["nc"]["3"]["nok_codigos"] = $nc["3"]["nok_codigos"];
        $indices["nc"]["3"]["%"] = $nc["3"]["%"];
		$indices["nc"]["3"]["ok_total"] = $nc["3"]["ok_total"];
		
        $indices = $this->aplicar_distribucion($indices, $codigo_area);
                
        $lista["indices"] = $indices;
        //print_r($lista);
        return $lista;
    }
    
    //Se obtienen las fechas de inicio y fin del informe, Fiscal Year
    function rango_fechas_busqueda()
    {
        $fecha = new Fecha();
        //echo "Año1: ".$fecha->getAno();
        $ano_actual = $fecha->getAno();
        $fecha_actual = $fecha->amdNumerico();        
        $ano_actual = $fecha->getAno();
        
        $fecha_inicio = $fecha->fiscalYear();
		$fecha_fin = date('Ymd'); //Nuevo 29-06-2012
		
        /*$fecha_fin = $ano_actual."0331";

        if($ano_actual < 2012)
        {
            $fecha_fin = $fecha_actual;
			//echo "hola";
        }
        else
        {            
            $fecha_fin = $fecha_actual;            
            $fecha_inicio = $fecha->restarTiempo(1);
            $fecha_inicio = str_replace("-", "", $fecha_inicio);
        } */               
        
        $fechas = array("fecha_actual" => $fecha_actual, 
                        "fecha_inicio" => $fecha_inicio,
                        "fecha_fin" => $fecha_fin);
                
        //echo "Fechas 1: ";
        //print_r($fechas);
        return $fechas;        
    }        
    
    //Se realiza la actualizaci�n de fechas de envio de planes de accion
    function actualizar_fechas()
    {
        $sql = "exec ri_informe_ice_aseguramiento_reporte_lista_correlativos";
        $lista = $this->select_list($sql);        
        if(is_array($lista) && (count($lista) > 0))
        {
            $contador = 1;
            foreach($lista as $correlativo)
            {                
                 $sql = "exec ri_informe_ice_aseguramiento_reporte_conversion_fecha '".$correlativo["idn_correlativo"]."'";
                 $sql .= ", '".date('Ymd H:m:s', $correlativo["idn_correlativo"])."'";
                 
                 //echo "<br>Contador: ".$contador;                 
                 $rs = $this->select($sql);
                 //$contador++;
            }
        }
    }
    
    /*******************************************************************************
    * 
    *                   DISTRIBUCION DE PESOS
    * 
    ********************************************************************************/
    
    //Se realiza la distribucion de los valores
    function aplicar_distribucion($indices, $id_area)
    {
        $total_indices = 9;
        $contador = 0;
        $keys = array_keys($this->PESOS);
        //print_r($indices);
		//exit(0);
        /*
         *           DISTRIBUCION
         */
        
        $suma_porcentajes_items = 0;
        foreach($keys as $key)
        {                                        
            $subitems = count($this->PESOS[$key]["pesos_subitems"]);
            $indices[$key]["peso_final"] = 0;
            
            //Se calculan los porcentajes que participan de la distribucion
            $suma_porcentajes = 0;
            $peso_corregido = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                if(($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0))
                {
					//echo "Key. $key ".$this->PESOS[$key]["pesos_subitems"]["$i"]."<br>";
                    $suma_porcentajes += $this->PESOS[$key]["pesos_subitems"]["$i"];
                    $peso_corregido += $this->PESOS[$key]["pesos_subitems"]["$i"];
                }                
            }  
			//echo "suma porcentajes: ".$suma_porcentajes;
             //echo "<br><br>";    
            //Calculo porcentaje sub-item       
            $porcentaje_real = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                $porcentaje_real = 0;
                if(($suma_porcentajes > 0) && (($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0)))
                {
                    $porcentaje_real = ($this->PESOS[$key]["pesos_subitems"]["$i"]*100) / $suma_porcentajes;
                }                                
                $indices[$key]["$i"]["porcentaje_real"] = $porcentaje_real;                    
               //echo "ICE : $key -> $i: ".
			   $indices[$key]["$i"]["ice"] = ($indices[$key]["$i"]["%"]*$porcentaje_real)/100;
			   //echo "<br>";
				//echo "Key: $key: ".$indices[$key]["$i"]["%"]." % Real: ".$porcentaje_real."<br>";;
                $indices[$key]["peso_final"] += $indices[$key]["$i"]["ice"];
            }
            
            //Peso final del item
            //echo "Peso final: $key ".
			$indices[$key]["peso_final"] = $indices[$key]["peso_final"]."<br>";
            $indices[$key]["peso_corregido"] = $peso_corregido;
                                        
            //$suma_porcentajes = 0;
            if($indices[$key]["peso_final"] > 0)
            {
                $suma_porcentajes_items += $this->PESOS[$key]["peso_item"];
            }        
			//$indices[$key]["peso_final"] = 50;                                                            
        }                                
        
        $indices["ice"] = 0;
        if($suma_porcentajes_items > 0)
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $sumar_ice = 0;
            foreach($keys as $key)
            {
                $indices[$key]["peso_final_item"] = $indices[$key]["peso_final"] * $this->PESOS[$key]["peso_item"] / 100;
                $sumar_ice = $indices[$key]["peso_final"] * ((100 * $this->PESOS[$key]["peso_item"]) / $suma_porcentajes_items) / 100; 
                //$indices["ice"] += $indices[$key]["peso_final_item"];
                $indices["ice"] += $sumar_ice;
            }

            //echo "ICE: ".
			$indices["ice"] = number_format($indices["ice"],1);
			//."<br>";
        }
        else
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $indices["ice"] = 0;                    
        }
               
        
        /*if($id_area == 37){
            echo "<br>% Item: ".$suma_porcentajes_items;                              
        }
                
        if($id_area == 37)
        {
            echo "<pre>";
            print_r($indices);
            echo "</pre>";
        }*/
//print_r($indices);
        return $indices;
    }
}


class InformeIceModelSO extends Model
{
    public static $MODULO = "informe_ice";

    var $PESOS = array("sub_pae"        => array("peso_item" => 40, "pesos_subitems" => array("1" => 100)));    
     
    var $title = array("incidentes" => array("name" => "INCIDENTES"),
                       "ctp_stp"    => array("name" => "CTP + STP", 
                                             "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                      "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)", 
                                                      "Por verificar y cerrar <br />(10 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "resto"      => array("name" => "RESTO", 
                                             "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                    "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)",
                                                    "Por verificar y cerrar <br />(10 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "sugerencias" => array("name" => "SUGERENCIAS", 
                                             "indice" => array("Por revisar <br />(30 %)",
                                                          "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "sub_pae" => array("name" => "PROGRAMA PREVENTIVO 2020",
                                          "indice" => array("Actividades programa preventivo"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido"),
                       "nc" => array("name" => "NC Auditor&iacute;a 2017",
                                          "indice" => array("No conformidades"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido")										  
										  );
               
    public static $LIMITE_PORCENTAJE = 90;
       
	function InformeIceModel() 
    {
		parent::Model();
        $this->MODULO_MODEL = InformeIceModel::$MODULO;
    }
	
    //Se obtiene el arreglo de titulos del informe
    function getTitulos()
    {
        return $this->title;
    }
    
    //Se obtiene el arbol de areas completo
    function arbol_areas()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
    
	//CONSTRUCCION Y FORESTAL
	
	    function arbol_areas_co_fo()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_co_fo";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_co_fo ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_co_fo";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	//DCC
	
	    function arbol_areas_dcc()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_dcc";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_dcc ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_dcc";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	
  //14-05-2019: RH, se agrega para nuevo ice
	  function arbol_areas_drs()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_drs";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_drs ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_drs";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	//KCCA
	
	    function arbol_areas_kcca()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_kcca";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_kcca ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_kcca";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
    //Se calculan los valores CTP + STP
    function calcular_ctp_stp($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual, $nuevas)
    {
		if($nuevas == 0) $fecha_inicio = "20130401";
		//else
        $sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
		$sql = "exec ri_informe_ice_calcular_ctp_stp ".$codigo_area.", '".$considera_hijas."', '";
        
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $ctp_stp_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $ctp_stp_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $ctp_stp_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $ctp_stp_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $ctp_stp_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]);
            $ctp_stp_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]);
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $ctp_stp_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$ctp_stp_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $ctp_stp_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$ctp_stp_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $ctp_stp_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$ctp_stp_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                                    
        }
        
        $ctp_stp = array("1" => $ctp_stp_1,
                         "2" => $ctp_stp_2,
                         "3" => $ctp_stp_3);
        
        return $ctp_stp;                        
    }
    
    //Se calculan los valores RESTO
    function calcular_resto($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {
		if($nuevas == 0) $fecha_inicio = "20130401";
		
		$sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
        $sql = "exec ri_informe_ice_calcular_resto ".$codigo_area.", '".$considera_hijas."', '";
        $sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
            
        $rs = $this->select($sql);
        $resto_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $resto_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $resto_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $resto_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
//			print_r($resto_1;
            $resto_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]
							   );
            $resto_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]
							   );           
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $resto_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$resto_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $resto_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$resto_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $resto_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$resto_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                        
        }
        
        $resto = array("1" => $resto_1,
                       "2" => $resto_2,
                       "3" => $resto_3);
        
        return $resto;
    }
        
    //Se calculan los valores SUGERENCIAS
    function calcular_sugerencias($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {
		if($nuevas == 0) $fecha_inicio = "20140401";
		
		$sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
        $sql = "exec ri_informe_ice_calcular_sugerencias ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
            
        $rs = $this->select($sql);
        $sugerencias_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $sugerencias_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);        
        if(!$rs->EOF)
        {               
            $sugerencias_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $sugerencias_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]
							   );
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $sugerencias_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$sugerencias_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
                        
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $sugerencias_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$sugerencias_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }                                    
        }
        
        $sugerencias = array("1" => $sugerencias_1,
                             "2" => $sugerencias_2);
        
        return $sugerencias;               
    }
        
    //Se calculan los valores 
    function calcular_sub_pae($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		$fecha_inicio = "20130401";
		
		$sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
        $sql = "exec ri_informe_ice_calcular_so ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
                    
        $rs = $this->select($sql);
        $sub_pae_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $sub_pae_1 = array("ok" => $rs->fields["ok"], 
                               "ok_codigos" => $rs->fields["ok_codigos"], 
                               "nok" => $rs->fields["nok"], 
                               "nok_codigos" => $rs->fields["nok_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
                               
            if(($rs->fields["ok"] > 0) || ($rs->fields["nok"] > 0))
            {
                $sub_pae_1["%"] = number_format(100*$rs->fields["ok"]/($rs->fields["ok"] + $rs->fields["nok"]),1);
				$sub_pae_1["%"] = number_format((100*$rs->fields["ok"])/($rs->fields["ok1_total"]),1);
            }            
        }
        
        $sub_pae = array("1" => $sub_pae_1);
        
        return $sub_pae;         
    }
    
    //Se calculan los valores 
    function calcular_nc($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		$fecha_inicio = "20120401";
		//$fecha_inicio = "01-01-2011";
		
		$sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
        $sql = "exec ri_informe_ice_calcular_nc ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        
        $rs = $this->select($sql);
        //$sub_pae_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0);
        if(!$rs->EOF)
        {    
			//echo "hola";           
            $nc_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
			//print_r($sub_pae_1);
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $nc_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$nc_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
        }
        
        $nc = array("1" => $nc_1);
        
        return $nc;         
    }
	
    //Se realiza el calculo de % final
    function calcular_porcentaje_area($valores)
    {
        $valor = 0;
        $valor = ($valores["ctp_stp_1"] + $valores["ctp_stp_2"] + $valores["ctp_stp_3"])/3 * $this->PESOS["ctp_stp"];
        $valor += ($valores["resto_1"] + $valores["resto_2"] + $valores["resto_3"]) * $this->PESOS["resto"];
        $valor += ($valores["sugerencias_1"] + $valores["sugerencias_2"]) * $this->PESOS["sugerencias"];
        $valor += ($valores["sub_pae"]) * $this->PESOS["sub_pae"];
		$valor += ($valores["nc"]) * $this->PESOS["nc"];
        
        return $valor;
    }
    
    //Se realiza el calculo de todos los indices
    function calculo_indices($codigo_area, $considera_hijas = "1",$fecha_desde,$fecha_hasta)
    {
        $fechas = $this->rango_fechas_busqueda();
                
        $indices = array();
        $porcentaje = 0;
		
		$nuevas = 0;
		if($fecha_desde<>'' and $fecha_hasta<>''){
			$fechas["fecha_inicio"] = $fecha_desde;
			$fechas["fecha_fin"] = $fecha_hasta;
			$nuevas = 1;	
		}
		
		//if($fecha_hasta<>'') $fechas["fecha_fin"] = $fecha_hasta;
		
		//echo $fechas["fecha_inicio"]." ".$fechas["fecha_fin"];
		$ctp_stp = $this->calcular_ctp_stp($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);

        $indices["ctp_stp"]["1"]["ok"] = $ctp_stp["1"]["ok"];
        $indices["ctp_stp"]["1"]["ok_codigos"] = $ctp_stp["1"]["ok_codigos"];
        $indices["ctp_stp"]["1"]["nok"] = $ctp_stp["1"]["nok"];
        $indices["ctp_stp"]["1"]["nok_codigos"] = $ctp_stp["1"]["nok_codigos"];        
        $indices["ctp_stp"]["1"]["%"] = $ctp_stp["1"]["%"];
		$indices["ctp_stp"]["1"]["ok_total"] = $ctp_stp["1"]["ok_total"];
        
        $indices["ctp_stp"]["2"]["ok"] = $ctp_stp["2"]["ok"];
        $indices["ctp_stp"]["2"]["ok_codigos"] = $ctp_stp["2"]["ok_codigos"];
        $indices["ctp_stp"]["2"]["nok"] = $ctp_stp["2"]["nok"];
        $indices["ctp_stp"]["2"]["nok_codigos"] = $ctp_stp["2"]["nok_codigos"];
        $indices["ctp_stp"]["2"]["%"] = $ctp_stp["2"]["%"];
		$indices["ctp_stp"]["2"]["ok_total"] = $ctp_stp["2"]["ok_total"];
        
        $indices["ctp_stp"]["3"]["ok"] = $ctp_stp["3"]["ok"];
        $indices["ctp_stp"]["3"]["ok_codigos"] = $ctp_stp["3"]["ok_codigos"];
        $indices["ctp_stp"]["3"]["nok"] = $ctp_stp["3"]["nok"];
        $indices["ctp_stp"]["3"]["nok_codigos"] = $ctp_stp["3"]["nok_codigos"];
        $indices["ctp_stp"]["3"]["%"] = $ctp_stp["3"]["%"];
		$indices["ctp_stp"]["3"]["ok_total"] = $ctp_stp["3"]["ok_total"];
        
        $resto = $this->calcular_resto($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);

        $indices["resto"]["1"]["ok"] = $resto["1"]["ok"];
        $indices["resto"]["1"]["ok_codigos"] = $resto["1"]["ok_codigos"]; 
        $indices["resto"]["1"]["nok"] = $resto["1"]["nok"];
        $indices["resto"]["1"]["nok_codigos"] = $resto["1"]["nok_codigos"];
        $indices["resto"]["1"]["%"] = $resto["1"]["%"];
		$indices["resto"]["1"]["ok_total"] = $resto["1"]["ok_total"];
        
        $indices["resto"]["2"]["ok"] = $resto["2"]["ok"];
        $indices["resto"]["2"]["ok_codigos"] = $resto["2"]["ok_codigos"];
        $indices["resto"]["2"]["nok"] = $resto["2"]["nok"];
        $indices["resto"]["2"]["nok_codigos"] = $resto["2"]["nok_codigos"];
        $indices["resto"]["2"]["%"] = $resto["2"]["%"];
		$indices["resto"]["2"]["ok_total"] = $resto["2"]["ok_total"];
        
        $indices["resto"]["3"]["ok"] = $resto["3"]["ok"];
        $indices["resto"]["3"]["ok_codigos"] = $resto["3"]["ok_codigos"];
        $indices["resto"]["3"]["nok"] = $resto["3"]["nok"];
        $indices["resto"]["3"]["nok_codigos"] = $resto["3"]["nok_codigos"];
        $indices["resto"]["3"]["%"] = $resto["3"]["%"];
		$indices["resto"]["3"]["ok_total"] = $resto["3"]["ok_total"];
        
        $sugerencias = $this->calcular_sugerencias($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
        
        $indices["sugerencias"]["1"]["ok"] = $sugerencias["1"]["ok"];
        $indices["sugerencias"]["1"]["ok_codigos"] = $sugerencias["1"]["ok_codigos"];
        $indices["sugerencias"]["1"]["nok"] = $sugerencias["1"]["nok"];
        $indices["sugerencias"]["1"]["nok_codigos"] = $sugerencias["1"]["nok_codigos"];
        $indices["sugerencias"]["1"]["%"] = $sugerencias["1"]["%"];
		$indices["sugerencias"]["1"]["ok_total"] = $sugerencias["1"]["ok_total"];
        
        $indices["sugerencias"]["2"]["ok"] = $sugerencias["2"]["ok"];
        $indices["sugerencias"]["2"]["ok_codigos"] = $sugerencias["2"]["ok_codigos"];
        $indices["sugerencias"]["2"]["nok"] = $sugerencias["2"]["nok"];
        $indices["sugerencias"]["2"]["nok_codigos"] = $sugerencias["2"]["nok_codigos"];
        $indices["sugerencias"]["2"]["%"] = $sugerencias["2"]["%"];
		$indices["sugerencias"]["2"]["ok_total"] = $sugerencias["2"]["ok_total"];
                        
        $sub_pae = $this->calcular_sub_pae($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
        
        $indices["sub_pae"]["1"]["ok"] = $sub_pae["1"]["ok"];
        $indices["sub_pae"]["1"]["ok_codigos"] = $sub_pae["1"]["ok_codigos"];
        $indices["sub_pae"]["1"]["nok"] = $sub_pae["1"]["nok"];
        $indices["sub_pae"]["1"]["nok_codigos"] = $sub_pae["1"]["nok_codigos"];
        $indices["sub_pae"]["1"]["%"] = $sub_pae["1"]["%"];
		$indices["sub_pae"]["1"]["ok_total"] = $sub_pae["1"]["ok_total"];

		$nc = $this->calcular_nc($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
		//print_r($nc);
        $indices["nc"]["1"]["ok"] = $nc["1"]["ok"];
        $indices["nc"]["1"]["ok_codigos"] = $nc["1"]["ok_codigos"];
        $indices["nc"]["1"]["nok"] = $nc["1"]["nok"];
        $indices["nc"]["1"]["nok_codigos"] = $nc["1"]["nok_codigos"];
        $indices["nc"]["1"]["%"] = $nc["1"]["%"];
		$indices["nc"]["1"]["ok_total"] = $nc["1"]["ok_total"];

        $indices = $this->aplicar_distribucion($indices, $codigo_area);
                
        $lista["indices"] = $indices;
        //print_r($lista);
        return $lista;
    }
    
    //Se obtienen las fechas de inicio y fin del informe, Fiscal Year
    function rango_fechas_busqueda()
    {
        $fecha = new Fecha();
        $ano_actual = $fecha->getAno();
        $fecha_actual = $fecha->amdNumerico();        
        $ano_actual = $fecha->getAno();
        
        $fecha_inicio = $fecha->fiscalYear(); //$ano_actual."0401";
		$fecha_fin = date('Ymd'); //Nuevo 29-06-2012
		
        /*$fecha_fin = $ano_actual."0331";

        if($ano_actual < 2012)
        {
            $fecha_fin = $fecha_actual;
			//echo "hola";
        }
        else
        {            
            $fecha_fin = $fecha_actual;            
            $fecha_inicio = $fecha->restarTiempo(1);
            $fecha_inicio = str_replace("-", "", $fecha_inicio);
        } */               
        
        $fechas = array("fecha_actual" => $fecha_actual, 
                        "fecha_inicio" => $fecha_inicio,
                        "fecha_fin" => $fecha_fin);
                
        
        //echo "Fechas 2: ";
        //print_r($fechas);
        return $fechas;        
    }        
    
    //Se realiza la actualizaci�n de fechas de envio de planes de accion
    function actualizar_fechas()
    {
        $sql = "exec ri_informe_ice_aseguramiento_reporte_lista_correlativos";
        $lista = $this->select_list($sql);        
        if(is_array($lista) && (count($lista) > 0))
        {
            $contador = 1;
            foreach($lista as $correlativo)
            {                
                 $sql = "exec ri_informe_ice_aseguramiento_reporte_conversion_fecha '".$correlativo["idn_correlativo"]."'";
                 $sql .= ", '".date('Ymd H:m:s', $correlativo["idn_correlativo"])."'";
                 
                 //echo "<br>Contador: ".$contador;                 
                 $rs = $this->select($sql);
                 //$contador++;
            }
        }
    }
    
    /*******************************************************************************
    * 
    *                   DISTRIBUCION DE PESOS
    * 
    ********************************************************************************/
    
    //Se realiza la distribucion de los valores
    function aplicar_distribucion($indices, $id_area)
    {
        $total_indices = 9;
        $contador = 0;
        $keys = array_keys($this->PESOS);
        //print_r($indices);
		//exit(0);
        /*
         *           DISTRIBUCION
         */
        
        $suma_porcentajes_items = 0;
        foreach($keys as $key)
        {                                        
            $subitems = count($this->PESOS[$key]["pesos_subitems"]);
            $indices[$key]["peso_final"] = 0;
            
            //Se calculan los porcentajes que participan de la distribucion
            $suma_porcentajes = 0;
            $peso_corregido = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                if(($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0))
                {
					//echo "Key. $key ".$this->PESOS[$key]["pesos_subitems"]["$i"]."<br>";
                    $suma_porcentajes += $this->PESOS[$key]["pesos_subitems"]["$i"];
                    $peso_corregido += $this->PESOS[$key]["pesos_subitems"]["$i"];
                }                
            }  
			//echo "suma porcentajes: ".$suma_porcentajes;
             //echo "<br><br>";    
            //Calculo porcentaje sub-item       
            $porcentaje_real = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                $porcentaje_real = 0;
                if(($suma_porcentajes > 0) && (($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0)))
                {
                    $porcentaje_real = ($this->PESOS[$key]["pesos_subitems"]["$i"]*100) / $suma_porcentajes;
                }                                
                $indices[$key]["$i"]["porcentaje_real"] = $porcentaje_real;                    
               //echo "ICE : $key -> $i: ".
			   $indices[$key]["$i"]["ice"] = ($indices[$key]["$i"]["%"]*$porcentaje_real)/100;
			   //echo "<br>";
				//echo "Key: $key: ".$indices[$key]["$i"]["%"]." % Real: ".$porcentaje_real."<br>";;
                $indices[$key]["peso_final"] += $indices[$key]["$i"]["ice"];
            }
            
            //Peso final del item
            //echo "Peso final: $key ".
			$indices[$key]["peso_final"] = $indices[$key]["peso_final"]."<br>";
            $indices[$key]["peso_corregido"] = $peso_corregido;
                                        
            //$suma_porcentajes = 0;
            if($indices[$key]["peso_final"] > 0)
            {
                $suma_porcentajes_items += $this->PESOS[$key]["peso_item"];
            }        
			//$indices[$key]["peso_final"] = 50;                                                            
        }                                
        
        $indices["ice"] = 0;
        if($suma_porcentajes_items > 0)
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $sumar_ice = 0;
            foreach($keys as $key)
            {
                $indices[$key]["peso_final_item"] = $indices[$key]["peso_final"] * $this->PESOS[$key]["peso_item"] / 100;
                $sumar_ice = $indices[$key]["peso_final"] * ((100 * $this->PESOS[$key]["peso_item"]) / $suma_porcentajes_items) / 100; 
                //$indices["ice"] += $indices[$key]["peso_final_item"];
                $indices["ice"] += $sumar_ice;
            }

            //echo "ICE: ".
			$indices["ice"] = number_format($indices["ice"],1);
			//."<br>";
        }
        else
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $indices["ice"] = 0;                    
        }
               
        
        /*if($id_area == 37){
            echo "<br>% Item: ".$suma_porcentajes_items;                              
        }
                
        if($id_area == 37)
        {
            echo "<pre>";
            print_r($indices);
            echo "</pre>";
        }*/
//print_r($indices);
        return $indices;
    }
}


class InformeIceModelMA extends Model
{
    public static $MODULO = "informe_ice";

    var $PESOS = array("sub_pae"        => array("peso_item" => 40, "pesos_subitems" => array("1" => 100)));    
     
    var $title = array("sub_pae" => array("name" => "PROGRAMA PREVENTIVO 2014",
                                          "indice" => array("Actividades programa preventivo"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido")										  
										  );
               
    public static $LIMITE_PORCENTAJE = 90;
       
	function InformeIceModel() 
    {
		parent::Model();
        $this->MODULO_MODEL = InformeIceModel::$MODULO;
    }
	
    //Se obtiene el arreglo de titulos del informe
    function getTitulos()
    {
        return $this->title;
    }
    
    //Se obtiene el arbol de areas completo
    function arbol_areas()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
    
					//CONSTRUCCION Y FORESTAL
					
						function arbol_areas_co_fo()
					{
						$areas = array();
						
						$sql = "exec ri_informe_ice_area_informe_principaleste_co_fo";
								
						$rs = $this->select($sql);        
						if(!$rs->EOF)
						{
							$principales = array();            
							while(!$rs->EOF)
							{
								$area = $rs->fields;
								$area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
								$principales[] = $area;
								$rs->MoveNext();
							}
							
				foreach($principales as $area)
				{
					$sql = "exec ri_informe_ice_area_informe_hijas_co_fo ".$area["id"];
									
					$rs = $this->select($sql);        
					if(!$rs->EOF)
					{
						$hijas = array();            
						while(!$rs->EOF)
						{
							$area_hija = $rs->fields;
							$area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
							$hijas[] = $area_hija;                
							$rs->MoveNext();
						}         
						   
						$area["hijas"] = $hijas;                    
					}                           
					$areas["principales"][] = $area; 
				}                        
			}
							
			$sql = "exec ri_informe_ice_area_informe_resumen_co_fo";
			$rs = $this->select($sql);        
			if(!$rs->EOF)
			{
				$resumen = array();            
				while(!$rs->EOF)
				{
					$area = $rs->fields;
					$area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
					$resumen[] = $area;
					
					$rs->MoveNext();
				}
				
				$areas["resumen"] = $resumen;
			}
			
			return $areas;
		}
		
		//DCC
		
			function arbol_areas_dcc()
		{
			$areas = array();
			
			$sql = "exec ri_informe_ice_area_informe_principales_dcc";
					
			$rs = $this->select($sql);        
			if(!$rs->EOF)
			{
				$principales = array();            
				while(!$rs->EOF)
				{
					$area = $rs->fields;
					$area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
					$principales[] = $area;
					$rs->MoveNext();
				}
				
				foreach($principales as $area)
				{
					$sql = "exec ri_informe_ice_area_informe_hijas_dcc ".$area["id"];
									
					$rs = $this->select($sql);        
					if(!$rs->EOF)
					{
						$hijas = array();            
						while(!$rs->EOF)
						{
							$area_hija = $rs->fields;
							$area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
							$hijas[] = $area_hija;                
							$rs->MoveNext();
						}         
						   
						$area["hijas"] = $hijas;                    
					}                           
					$areas["principales"][] = $area; 
				}                        
			}
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_dcc";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	
  //14-05-2019: RH, se agrega para nuevo ice
	  function arbol_areas_drs()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_drs";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_drs ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_drs";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	//KCCA
	
	    function arbol_areas_kcca()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_kcca";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_kcca ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_kcca";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	

        

        
    //Se calculan los valores 
    function calcular_sub_pae($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		$fecha_inicio = "20150401";
		
        $sql = "exec ri_informe_ice_calcular_ma ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
                    
        $rs = $this->select($sql);
        $sub_pae_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $sub_pae_1 = array("ok" => $rs->fields["ok"], 
                               "ok_codigos" => $rs->fields["ok_codigos"], 
                               "nok" => $rs->fields["nok"], 
                               "nok_codigos" => $rs->fields["nok_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
                               
            if(($rs->fields["ok"] > 0) || ($rs->fields["nok"] > 0))
            {
                $sub_pae_1["%"] = number_format(100*$rs->fields["ok"]/($rs->fields["ok"] + $rs->fields["nok"]),1);
				$sub_pae_1["%"] = number_format((100*$rs->fields["ok"])/($rs->fields["ok1_total"]),1);
            }            
        }
        
        $sub_pae = array("1" => $sub_pae_1);
        
        return $sub_pae;         
    }
    
   //Se realiza el calculo de % final
    function calcular_porcentaje_area($valores)
    {
        $valor = 0;
        $valor = ($valores["ctp_stp_1"] + $valores["ctp_stp_2"] + $valores["ctp_stp_3"])/3 * $this->PESOS["ctp_stp"];
        $valor += ($valores["resto_1"] + $valores["resto_2"] + $valores["resto_3"]) * $this->PESOS["resto"];
        $valor += ($valores["sugerencias_1"] + $valores["sugerencias_2"]) * $this->PESOS["sugerencias"];
        $valor += ($valores["sub_pae"]) * $this->PESOS["sub_pae"];
		$valor += ($valores["nc"]) * $this->PESOS["nc"];
        
        return $valor;
    }
    
    //Se realiza el calculo de todos los indices
    function calculo_indices($codigo_area, $considera_hijas = "1",$fecha_desde,$fecha_hasta)
    {
        $fechas = $this->rango_fechas_busqueda();
                
        $indices = array();
        $porcentaje = 0;
		
		$nuevas = 0;
		if($fecha_desde<>'' and $fecha_hasta<>''){
			$fechas["fecha_inicio"] = $fecha_desde;
			$fechas["fecha_fin"] = $fecha_hasta;
			$nuevas = 1;	
		}
		
		//if($fecha_hasta<>'') $fechas["fecha_fin"] = $fecha_hasta;
		
		//echo $fechas["fecha_inicio"]." ".$fechas["fecha_fin"];
                        
        $sub_pae = $this->calcular_sub_pae($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
        
        $indices["sub_pae"]["1"]["ok"] = $sub_pae["1"]["ok"];
        $indices["sub_pae"]["1"]["ok_codigos"] = $sub_pae["1"]["ok_codigos"];
        $indices["sub_pae"]["1"]["nok"] = $sub_pae["1"]["nok"];
        $indices["sub_pae"]["1"]["nok_codigos"] = $sub_pae["1"]["nok_codigos"];
        $indices["sub_pae"]["1"]["%"] = $sub_pae["1"]["%"];
		$indices["sub_pae"]["1"]["ok_total"] = $sub_pae["1"]["ok_total"];

        $indices = $this->aplicar_distribucion($indices, $codigo_area);
                
        $lista["indices"] = $indices;
        //print_r($lista);
        return $lista;
    }
    
    //Se obtienen las fechas de inicio y fin del informe, Fiscal Year
    function rango_fechas_busqueda()
    {
        $fecha = new Fecha();
        $ano_actual = $fecha->getAno();
        $fecha_actual = $fecha->amdNumerico();        
        $ano_actual = $fecha->getAno();
        
        $fecha_inicio = $fecha->fiscalYear(); //$ano_actual."0401";
		$fecha_fin = date('Ymd'); //Nuevo 29-06-2012
		
        /*$fecha_fin = $ano_actual."0331";

        if($ano_actual < 2012)
        {
            $fecha_fin = $fecha_actual;
			//echo "hola";
        }
        else
        {            
            $fecha_fin = $fecha_actual;            
            $fecha_inicio = $fecha->restarTiempo(1);
            $fecha_inicio = str_replace("-", "", $fecha_inicio);
        } */               
        
        $fechas = array("fecha_actual" => $fecha_actual, 
                        "fecha_inicio" => $fecha_inicio,
                        "fecha_fin" => $fecha_fin);
                
        //echo "Fechas 3: ";
        //print_r( $fechas);
        return $fechas;        
    }        
    
    //Se realiza la actualizaci�n de fechas de envio de planes de accion
    function actualizar_fechas()
    {
        $sql = "exec ri_informe_ice_aseguramiento_reporte_lista_correlativos";
        $lista = $this->select_list($sql);        
        if(is_array($lista) && (count($lista) > 0))
        {
            $contador = 1;
            foreach($lista as $correlativo)
            {                
                 $sql = "exec ri_informe_ice_aseguramiento_reporte_conversion_fecha '".$correlativo["idn_correlativo"]."'";
                 $sql .= ", '".date('Ymd H:m:s', $correlativo["idn_correlativo"])."'";
                 
                 //echo "<br>Contador: ".$contador;                 
                 $rs = $this->select($sql);
                 //$contador++;
            }
        }
    }
    
    /*******************************************************************************
    * 
    *                   DISTRIBUCION DE PESOS
    * 
    ********************************************************************************/
    
    //Se realiza la distribucion de los valores
    function aplicar_distribucion($indices, $id_area)
    {
        $total_indices = 9;
        $contador = 0;
        $keys = array_keys($this->PESOS);
        //print_r($indices);
		//exit(0);
        /*
         *           DISTRIBUCION
         */
        
        $suma_porcentajes_items = 0;
        foreach($keys as $key)
        {                                        
            $subitems = count($this->PESOS[$key]["pesos_subitems"]);
            $indices[$key]["peso_final"] = 0;
            
            //Se calculan los porcentajes que participan de la distribucion
            $suma_porcentajes = 0;
            $peso_corregido = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                if(($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0))
                {
					//echo "Key. $key ".$this->PESOS[$key]["pesos_subitems"]["$i"]."<br>";
                    $suma_porcentajes += $this->PESOS[$key]["pesos_subitems"]["$i"];
                    $peso_corregido += $this->PESOS[$key]["pesos_subitems"]["$i"];
                }                
            }  
			//echo "suma porcentajes: ".$suma_porcentajes;
             //echo "<br><br>";    
            //Calculo porcentaje sub-item       
            $porcentaje_real = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                $porcentaje_real = 0;
                if(($suma_porcentajes > 0) && (($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0)))
                {
                    $porcentaje_real = ($this->PESOS[$key]["pesos_subitems"]["$i"]*100) / $suma_porcentajes;
                }                                
                $indices[$key]["$i"]["porcentaje_real"] = $porcentaje_real;                    
               //echo "ICE : $key -> $i: ".
			   $indices[$key]["$i"]["ice"] = ($indices[$key]["$i"]["%"]*$porcentaje_real)/100;
			   //echo "<br>";
				//echo "Key: $key: ".$indices[$key]["$i"]["%"]." % Real: ".$porcentaje_real."<br>";;
                $indices[$key]["peso_final"] += $indices[$key]["$i"]["ice"];
            }
            
            //Peso final del item
            //echo "Peso final: $key ".
			$indices[$key]["peso_final"] = $indices[$key]["peso_final"]."<br>";
            $indices[$key]["peso_corregido"] = $peso_corregido;
                                        
            //$suma_porcentajes = 0;
            if($indices[$key]["peso_final"] > 0)
            {
                $suma_porcentajes_items += $this->PESOS[$key]["peso_item"];
            }        
			//$indices[$key]["peso_final"] = 50;                                                            
        }                                
        
        $indices["ice"] = 0;
        if($suma_porcentajes_items > 0)
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $sumar_ice = 0;
            foreach($keys as $key)
            {
                $indices[$key]["peso_final_item"] = $indices[$key]["peso_final"] * $this->PESOS[$key]["peso_item"] / 100;
                $sumar_ice = $indices[$key]["peso_final"] * ((100 * $this->PESOS[$key]["peso_item"]) / $suma_porcentajes_items) / 100; 
                //$indices["ice"] += $indices[$key]["peso_final_item"];
                $indices["ice"] += $sumar_ice;
            }

            //echo "ICE: ".
			$indices["ice"] = number_format($indices["ice"],1);
			//."<br>";
        }
        else
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $indices["ice"] = 0;                    
        }
               
        
        /*if($id_area == 37){
            echo "<br>% Item: ".$suma_porcentajes_items;                              
        }
                
        if($id_area == 37)
        {
            echo "<pre>";
            print_r($indices);
            echo "</pre>";
        }*/
//print_r($indices);
        return $indices;
    }
}


class InformeIceModelFlotante extends Model
{
    public static $MODULO = "informe_ice";

    var $PESOS = array("ctp_stp"        => array("peso_item" => 35, "pesos_subitems" => array("1" => 20, "2" => 70, "3" => 10)), 
                       "resto"          => array("peso_item" => 10, "pesos_subitems" => array("1" => 20, "2" => 70, "3" => 10)), 
                       "sugerencias"    => array("peso_item" => 5,  "pesos_subitems" => array("1" => 30, "2" => 70)), 
                       "sub_pae"        => array("peso_item" => 40, "pesos_subitems" => array("1" => 100)),
					   "nc"          => array("peso_item" => 10, "pesos_subitems" => array("1" => 20, "2" => 70, "3" => 10)));    
     
    var $title = array("incidentes" => array("name" => ""),
                       "ctp_stp"    => array("name" => "ACCIDENTES CTP + STP (12 meses flotantes)", 
                                             "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                      "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)", 
                                                      "Por verificar y cerrar <br />(10 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "resto"      => array("name" => "RESTO DE INCIDENTES + NO CONFORMIDADES + TRANSGRESIONES (3 meses flotantes)", 
                                             "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                    "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)",
                                                    "Por verificar y cerrar <br />(10 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "sugerencias" => array("name" => "IDEAS DE MEJORA + TRATAMIENTO DE ACCIONES Y CONDICIONES SUBESTANDARES (3 meses flotantes)", 
                                             "indice" => array("Por revisar <br />(30 %)",
                                                          "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "sub_pae" => array("name" => "ACTIVIDADES DEL PROGRAMA PREVENTIVO FY20 ",
                                          "indice" => array("Actividades programa preventivo"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido"),
						"nc" => array("name" => "NC Auditor&iacute;a 2016",
                                          "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                      "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)", 
                                                      "Por verificar y cerrar <br />(10 %)"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido")										  
										  );
                       /*"nc" => array("name" => "NC Auditor�a Programa Preventivo FY15 (Cada vez)",
                                          "indice" => array("No conformidades"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido")										  
										  );*/
               
    public static $LIMITE_PORCENTAJE = 90;
       
	function InformeIceModel() 
    {
		parent::Model();
        $this->MODULO_MODEL = InformeIceModel::$MODULO;
    }
	
    //Se obtiene el arreglo de titulos del informe
    function getTitulos()
    {
        return $this->title;
    }
    
    //Se obtiene el arbol de areas completo
    function arbol_areas()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
 
     //Se obtiene el arbol de areas completo
	    function arbol_areas_co_fo()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_co_fo";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_co_fo ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_co_fo";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }

 
 
    
    //Se calculan los valores CTP + STP
    function calcular_ctp_stp($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual, $nuevas)
    {
	
		$sql = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
		$rs = $this->select($sql);
		if(!$rs->EOF)
        {
			$fecIni = $rs->fields["fec"];
		}
		$fec = explode("/",$fecIni);
		
		$fecha_inicio = "20070101";
		$fecha_inicio = $fec[2].$fec[1].$fec[0];
		//else
        
		
		$sql = "exec ri_informe_ice_calcular_ctp_stp ".$codigo_area.", '".$considera_hijas."', '";
        
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $ctp_stp_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $ctp_stp_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $ctp_stp_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $ctp_stp_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $ctp_stp_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]);
            $ctp_stp_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]);
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $ctp_stp_1["%"] = (100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]));
				$ctp_stp_1["%"] = (100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $ctp_stp_2["%"] = (100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]));
				$ctp_stp_2["%"] = (100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $ctp_stp_3["%"] = (100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]));
				$ctp_stp_3["%"] = (100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]);
            }                                    
        }
        
        $ctp_stp = array("1" => $ctp_stp_1,
                         "2" => $ctp_stp_2,
                         "3" => $ctp_stp_3);
        
        return $ctp_stp;                        
    }
    
    //Se calculan los valores RESTO
    function calcular_resto($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {
		$sql = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
		$rs = $this->select($sql);
		if(!$rs->EOF)
        {
			$fecIni = $rs->fields["fec"];
		}
		$fec = explode("/",$fecIni);
		
		$fecha_inicio = "20070101";
		$fecha_inicio = $fec[2].$fec[1].$fec[0];
		
        $sql = "exec ri_informe_ice_calcular_resto ".$codigo_area.", '".$considera_hijas."', '";
        $sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
            
        $rs = $this->select($sql);
        $resto_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $resto_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $resto_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $resto_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );

            $resto_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]
							   );
            $resto_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]
							   );           
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $resto_1["%"] = (100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]));
				$resto_1["%"] = (100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $resto_2["%"] = (100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]));
				$resto_2["%"] = (100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $resto_3["%"] = (100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]));
				$resto_3["%"] = (100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]);
            }                        
        }
        
        $resto = array("1" => $resto_1,
                       "2" => $resto_2,
                       "3" => $resto_3);
        
        return $resto;
    }
        
    //Se calculan los valores SUGERENCIAS
    function calcular_sugerencias($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {
		$sql = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
		$rs = $this->select($sql);
		if(!$rs->EOF)
        {
			$fecIni = $rs->fields["fec"];
		}
		$fec = explode("/",$fecIni);
		
		$fecha_inicio = "20070101";
		$fecha_inicio = $fec[2].$fec[1].$fec[0];
		
        $sql = "exec ri_informe_ice_calcular_sugerencias ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
            
        $rs = $this->select($sql);
        $sugerencias_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $sugerencias_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);        
        if(!$rs->EOF)
        {               
            $sugerencias_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $sugerencias_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]
							   );
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $sugerencias_1["%"] = (100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]));
				$sugerencias_1["%"] = (100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]);
            }            
                        
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $sugerencias_2["%"] = (100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]));
				$sugerencias_2["%"] = (100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]);
            }                                    
        }
        
        $sugerencias = array("1" => $sugerencias_1,
                             "2" => $sugerencias_2);
        
        return $sugerencias;               
    }
        
    //Se calculan los valores 
    function calcular_sub_pae($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		$sql = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
		$rs = $this->select($sql);
		if(!$rs->EOF)
        {
			$fecIni = $rs->fields["fec"];
		}
		$fec = explode("/",$fecIni);
		
		$fecha_inicio = "20070101";
		$fecha_inicio = $fec[2].$fec[1].$fec[0];
		
        $sql = "exec ri_informe_ice_calcular_sub_pae_3meses ".$codigo_area.", '".$considera_hijas."', '";
		//$sql = "exec ri_informe_ice_calcular_sub_pae ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
                    
        $rs = $this->select($sql);
        $sub_pae_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $sub_pae_1 = array("ok" => $rs->fields["ok"], 
                               "ok_codigos" => $rs->fields["ok_codigos"], 
                               "nok" => $rs->fields["nok"], 
                               "nok_codigos" => $rs->fields["nok_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
                               
            if(($rs->fields["ok"] > 0) || ($rs->fields["nok"] > 0))
            {
                $sub_pae_1["%"] = (100*$rs->fields["ok"]/($rs->fields["ok"] + $rs->fields["nok"]));
				$sub_pae_1["%"] = (100*$rs->fields["ok"])/($rs->fields["ok1_total"]);
            }            
        }
        
        $sub_pae = array("1" => $sub_pae_1);
        
        return $sub_pae;         
    }
    
    //Se calculan los valores 
    function calcular_nc($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		if($nuevas == 0) $fecha_inicio = "20151223";
		//else
		$sql = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
		$rs = $this->select($sql);
		if(!$rs->EOF)
        {
			$fecIni = $rs->fields["fec"];
		}
		$fec = explode("/",$fecIni);
		
		$fecha_inicio = "20070101";
		$fecha_inicio = $fec[2].$fec[1].$fec[0];
		
		$sql = "exec ri_informe_ice_calcular_nc2 ".$codigo_area.", '".$considera_hijas."', '";
        
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $ctp_stp_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $ctp_stp_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $ctp_stp_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $ctp_stp_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $ctp_stp_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]);
            $ctp_stp_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]);
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $ctp_stp_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$ctp_stp_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $ctp_stp_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$ctp_stp_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $ctp_stp_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$ctp_stp_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                                    
        }
        
        $nc = array("1" => $ctp_stp_1,
		
                         "2" => $ctp_stp_2,
                         "3" => $ctp_stp_3);
        
        return $nc;           
    }
	
    //Se realiza el calculo de % final
    function calcular_porcentaje_area($valores)
    {
        $valor = 0;
        $valor = ($valores["ctp_stp_1"] + $valores["ctp_stp_2"] + $valores["ctp_stp_3"])/3 * $this->PESOS["ctp_stp"];
        $valor += ($valores["resto_1"] + $valores["resto_2"] + $valores["resto_3"]) * $this->PESOS["resto"];
        $valor += ($valores["sugerencias_1"] + $valores["sugerencias_2"]) * $this->PESOS["sugerencias"];
        $valor += ($valores["sub_pae"]) * $this->PESOS["sub_pae"];
		$valor += ($valores["nc"]) * $this->PESOS["nc"];
        
        return $valor;
    }
    
    //Se realiza el calculo de todos los indices
    function calculo_indices($codigo_area, $considera_hijas = "1",$fecha_desde,$fecha_hasta)
    {
        $fechas = $this->rango_fechas_busqueda();
                
        $indices = array();
        $porcentaje = 0;
		
		$nuevas = 0;
		if($fecha_desde<>'' and $fecha_hasta<>''){
			$fechas["fecha_inicio"] = $fecha_desde;
			$fechas["fecha_fin"] = $fecha_hasta;
			$nuevas = 1;	
		}
		
		//if($fecha_hasta<>'') $fechas["fecha_fin"] = $fecha_hasta;
		
		//echo $fechas["fecha_inicio"]." ".$fechas["fecha_fin"];
		$ctp_stp = $this->calcular_ctp_stp($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);

        $indices["ctp_stp"]["1"]["ok"] = $ctp_stp["1"]["ok"];
        $indices["ctp_stp"]["1"]["ok_codigos"] = $ctp_stp["1"]["ok_codigos"];
        $indices["ctp_stp"]["1"]["nok"] = $ctp_stp["1"]["nok"];
        $indices["ctp_stp"]["1"]["nok_codigos"] = $ctp_stp["1"]["nok_codigos"];        
        $indices["ctp_stp"]["1"]["%"] = $ctp_stp["1"]["%"];
		$indices["ctp_stp"]["1"]["ok_total"] = $ctp_stp["1"]["ok_total"];
        
        $indices["ctp_stp"]["2"]["ok"] = $ctp_stp["2"]["ok"];
        $indices["ctp_stp"]["2"]["ok_codigos"] = $ctp_stp["2"]["ok_codigos"];
        $indices["ctp_stp"]["2"]["nok"] = $ctp_stp["2"]["nok"];
        $indices["ctp_stp"]["2"]["nok_codigos"] = $ctp_stp["2"]["nok_codigos"];
        $indices["ctp_stp"]["2"]["%"] = $ctp_stp["2"]["%"];
		$indices["ctp_stp"]["2"]["ok_total"] = $ctp_stp["2"]["ok_total"];
        
        $indices["ctp_stp"]["3"]["ok"] = $ctp_stp["3"]["ok"];
        $indices["ctp_stp"]["3"]["ok_codigos"] = $ctp_stp["3"]["ok_codigos"];
        $indices["ctp_stp"]["3"]["nok"] = $ctp_stp["3"]["nok"];
        $indices["ctp_stp"]["3"]["nok_codigos"] = $ctp_stp["3"]["nok_codigos"];
        $indices["ctp_stp"]["3"]["%"] = $ctp_stp["3"]["%"];
		$indices["ctp_stp"]["3"]["ok_total"] = $ctp_stp["3"]["ok_total"];
        
        $resto = $this->calcular_resto($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);

        $indices["resto"]["1"]["ok"] = $resto["1"]["ok"];
        $indices["resto"]["1"]["ok_codigos"] = $resto["1"]["ok_codigos"]; 
        $indices["resto"]["1"]["nok"] = $resto["1"]["nok"];
        $indices["resto"]["1"]["nok_codigos"] = $resto["1"]["nok_codigos"];
        $indices["resto"]["1"]["%"] = $resto["1"]["%"];
		$indices["resto"]["1"]["ok_total"] = $resto["1"]["ok_total"];
        
        $indices["resto"]["2"]["ok"] = $resto["2"]["ok"];
        $indices["resto"]["2"]["ok_codigos"] = $resto["2"]["ok_codigos"];
        $indices["resto"]["2"]["nok"] = $resto["2"]["nok"];
        $indices["resto"]["2"]["nok_codigos"] = $resto["2"]["nok_codigos"];
        $indices["resto"]["2"]["%"] = $resto["2"]["%"];
		$indices["resto"]["2"]["ok_total"] = $resto["2"]["ok_total"];
        
        $indices["resto"]["3"]["ok"] = $resto["3"]["ok"];
        $indices["resto"]["3"]["ok_codigos"] = $resto["3"]["ok_codigos"];
        $indices["resto"]["3"]["nok"] = $resto["3"]["nok"];
        $indices["resto"]["3"]["nok_codigos"] = $resto["3"]["nok_codigos"];
        $indices["resto"]["3"]["%"] = $resto["3"]["%"];
		$indices["resto"]["3"]["ok_total"] = $resto["3"]["ok_total"];
        
        $sugerencias = $this->calcular_sugerencias($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
        
        $indices["sugerencias"]["1"]["ok"] = $sugerencias["1"]["ok"];
        $indices["sugerencias"]["1"]["ok_codigos"] = $sugerencias["1"]["ok_codigos"];
        $indices["sugerencias"]["1"]["nok"] = $sugerencias["1"]["nok"];
        $indices["sugerencias"]["1"]["nok_codigos"] = $sugerencias["1"]["nok_codigos"];
        $indices["sugerencias"]["1"]["%"] = $sugerencias["1"]["%"];
		$indices["sugerencias"]["1"]["ok_total"] = $sugerencias["1"]["ok_total"];
        
        $indices["sugerencias"]["2"]["ok"] = $sugerencias["2"]["ok"];
        $indices["sugerencias"]["2"]["ok_codigos"] = $sugerencias["2"]["ok_codigos"];
        $indices["sugerencias"]["2"]["nok"] = $sugerencias["2"]["nok"];
        $indices["sugerencias"]["2"]["nok_codigos"] = $sugerencias["2"]["nok_codigos"];
        $indices["sugerencias"]["2"]["%"] = $sugerencias["2"]["%"];
		$indices["sugerencias"]["2"]["ok_total"] = $sugerencias["2"]["ok_total"];
                        
        $sub_pae = $this->calcular_sub_pae($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
        
        $indices["sub_pae"]["1"]["ok"] = $sub_pae["1"]["ok"];
        $indices["sub_pae"]["1"]["ok_codigos"] = $sub_pae["1"]["ok_codigos"];
        $indices["sub_pae"]["1"]["nok"] = $sub_pae["1"]["nok"];
        $indices["sub_pae"]["1"]["nok_codigos"] = $sub_pae["1"]["nok_codigos"];
        $indices["sub_pae"]["1"]["%"] = $sub_pae["1"]["%"];
		$indices["sub_pae"]["1"]["ok_total"] = $sub_pae["1"]["ok_total"];

		$nc = $this->calcular_nc($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
		//print_r($nc);
        $indices["nc"]["1"]["ok"] = $nc["1"]["ok"];
        $indices["nc"]["1"]["ok_codigos"] = $nc["1"]["ok_codigos"];
        $indices["nc"]["1"]["nok"] = $nc["1"]["nok"];
        $indices["nc"]["1"]["nok_codigos"] = $nc["1"]["nok_codigos"];
        $indices["nc"]["1"]["%"] = $nc["1"]["%"];
		$indices["nc"]["1"]["ok_total"] = $nc["1"]["ok_total"];
		
        $indices["nc"]["2"]["ok"] = $nc["2"]["ok"];
        $indices["nc"]["2"]["ok_codigos"] = $nc["2"]["ok_codigos"];
        $indices["nc"]["2"]["nok"] = $nc["2"]["nok"];
        $indices["nc"]["2"]["nok_codigos"] = $nc["2"]["nok_codigos"];
        $indices["nc"]["2"]["%"] = $nc["2"]["%"];
		$indices["nc"]["2"]["ok_total"] = $nc["2"]["ok_total"];
		
        $indices["nc"]["3"]["ok"] = $nc["3"]["ok"];
        $indices["nc"]["3"]["ok_codigos"] = $nc["3"]["ok_codigos"];
        $indices["nc"]["3"]["nok"] = $nc["3"]["nok"];
        $indices["nc"]["3"]["nok_codigos"] = $nc["3"]["nok_codigos"];
        $indices["nc"]["3"]["%"] = $nc["3"]["%"];
		$indices["nc"]["3"]["ok_total"] = $nc["3"]["ok_total"];

        $indices = $this->aplicar_distribucion($indices, $codigo_area);
                
        $lista["indices"] = $indices;
        //print_r($lista);
        return $lista;
    }
    
    //Se obtienen las fechas de inicio y fin del informe, Fiscal Year
    function rango_fechas_busqueda()
    {
        $fecha = new Fecha();
        $ano_actual = $fecha->getAno();
        $fecha_actual = $fecha->amdNumerico();        
        $ano_actual = $fecha->getAno();
        
        $fecha_inicio = $fecha->fiscalYear(); //$ano_actual."0401";
		$fecha_fin = date('Ymd'); //Nuevo 29-06-2012
		
        /*$fecha_fin = $ano_actual."0331";

        if($ano_actual < 2012)
        {
            $fecha_fin = $fecha_actual;
			//echo "hola";
        }
        else
        {            
            $fecha_fin = $fecha_actual;            
            $fecha_inicio = $fecha->restarTiempo(1);
            $fecha_inicio = str_replace("-", "", $fecha_inicio);
        } */               
        
        $fechas = array("fecha_actual" => $fecha_actual, 
                        "fecha_inicio" => $fecha_inicio,
                        "fecha_fin" => $fecha_fin);
          
        //echo "Fechas 4:";
        //print_r($fechas);      
        return $fechas;        
    }        
    
    //Se realiza la actualizaci�n de fechas de envio de planes de accion
    function actualizar_fechas()
    {
        $sql = "exec ri_informe_ice_aseguramiento_reporte_lista_correlativos";
        $lista = $this->select_list($sql);        
        if(is_array($lista) && (count($lista) > 0))
        {
            $contador = 1;
            foreach($lista as $correlativo)
            {                
                 $sql = "exec ri_informe_ice_aseguramiento_reporte_conversion_fecha '".$correlativo["idn_correlativo"]."'";
                 $sql .= ", '".date('Ymd H:m:s', $correlativo["idn_correlativo"])."'";
                 
                 //echo "<br>Contador: ".$contador;                 
                 $rs = $this->select($sql);
                 //$contador++;
            }
        }
    }
    
    /*******************************************************************************
    * 
    *                   DISTRIBUCION DE PESOS
    * 
    ********************************************************************************/
    
    //Se realiza la distribucion de los valores
    function aplicar_distribucion($indices, $id_area)
    {
        $total_indices = 9;
        $contador = 0;
        $keys = array_keys($this->PESOS);
        //print_r($indices);
		//exit(0);
        /*
         *           DISTRIBUCION
         */
        
        $suma_porcentajes_items = 0;
        foreach($keys as $key)
        {                                        
            $subitems = count($this->PESOS[$key]["pesos_subitems"]);
            $indices[$key]["peso_final"] = 0;
            
            //Se calculan los porcentajes que participan de la distribucion
            $suma_porcentajes = 0;
            $peso_corregido = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                if(($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0))
                {
					//echo "Key. $key ".$this->PESOS[$key]["pesos_subitems"]["$i"]."<br>";
                    $suma_porcentajes += $this->PESOS[$key]["pesos_subitems"]["$i"];
                    $peso_corregido += $this->PESOS[$key]["pesos_subitems"]["$i"];
                }                
            }  
			//echo "suma porcentajes: ".$suma_porcentajes;
             //echo "<br><br>";    
            //Calculo porcentaje sub-item       
            $porcentaje_real = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                $porcentaje_real = 0;
                if(($suma_porcentajes > 0) && (($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0)))
                {
                    $porcentaje_real = ($this->PESOS[$key]["pesos_subitems"]["$i"]*100) / $suma_porcentajes;
                }                                
                $indices[$key]["$i"]["porcentaje_real"] = $porcentaje_real;                    
               //echo "ICE : $key -> $i: ".
			   $indices[$key]["$i"]["ice"] = ($indices[$key]["$i"]["%"]*$porcentaje_real)/100;
			   //echo "<br>";
				//echo "Key: $key: ".$indices[$key]["$i"]["%"]." % Real: ".$porcentaje_real."<br>";;
                $indices[$key]["peso_final"] += $indices[$key]["$i"]["ice"];
            }
            
            //Peso final del item
            //echo "Peso final: $key ".
			$indices[$key]["peso_final"] = $indices[$key]["peso_final"]."<br>";
            $indices[$key]["peso_corregido"] = $peso_corregido;
                                        
            //$suma_porcentajes = 0;
            if($indices[$key]["peso_final"] > 0)
            {
                $suma_porcentajes_items += $this->PESOS[$key]["peso_item"];
            }        
			//$indices[$key]["peso_final"] = 50;                                                            
        }                                
        
        $indices["ice"] = 0;
        if($suma_porcentajes_items > 0)
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $sumar_ice = 0;
            foreach($keys as $key)
            {
                $indices[$key]["peso_final_item"] = $indices[$key]["peso_final"] * $this->PESOS[$key]["peso_item"] / 100;
                $sumar_ice = $indices[$key]["peso_final"] * ((100 * $this->PESOS[$key]["peso_item"]) / $suma_porcentajes_items) / 100; 
                //$indices["ice"] += $indices[$key]["peso_final_item"];
                $indices["ice"] += $sumar_ice;
            }

            //echo "ICE: ".
			//$indices["ice"] = ($indices["ice"]);
			$indices["ice"] = number_format($indices["ice"],1);
			//."<br>";
        }
        else
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $indices["ice"] = 0;                    
        }
               
        
        /*if($id_area == 37){
            echo "<br>% Item: ".$suma_porcentajes_items;                              
        }
                
        if($id_area == 37)
        {
            echo "<pre>";
            print_r($indices);
            echo "</pre>";
        }*/
//print_r($indices);
        return $indices;
    }
}


class InformeIceModelFlotante2 extends Model
{
    public static $MODULO = "informe_ice";

    var $PESOS = array("ctp_stp"        => array("peso_item" => 35, "pesos_subitems" => array("1" => 20, "2" => 70, "3" => 10)), 
                       "resto"          => array("peso_item" => 10, "pesos_subitems" => array("1" => 20, "2" => 70, "3" => 10)), 
                       "sugerencias"    => array("peso_item" => 5,  "pesos_subitems" => array("1" => 30, "2" => 70)), 
                       "sub_pae"        => array("peso_item" => 40, "pesos_subitems" => array("1" => 100)),
					   "nc"          => array("peso_item" => 10, "pesos_subitems" => array("1" => 100)));    
     
    var $title = array("incidentes" => array("name" => ""),
                       "ctp_stp"    => array("name" => "ACCIDENTES CTP + STP (3 meses flotantes)", 
                                             "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                      "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)", 
                                                      "Por verificar y cerrar <br />(10 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "resto"      => array("name" => "RESTO DE INCIDENTES + NO CONFORMIDADES + TRANSGRESIONES (3 meses flotantes)", 
                                             "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                    "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)",
                                                    "Por verificar y cerrar <br />(10 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "sugerencias" => array("name" => "IDEAS DE MEJORA + TRATAMIENTO DE ACCIONES Y CONDICIONES SUBESTANDARES (3 meses flotantes)", 
                                             "indice" => array("Por revisar <br />(30 %)",
                                                          "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "sub_pae" => array("name" => "ACTIVIDADES DEL PROGRAMA PREVENTIVO FY20",
                                          "indice" => array("Actividades programa preventivo"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido"),
						/*"nc" => array("name" => "NC Auditor�a 2015",
                                          "indice" => array( 
                                                      "En implementaci�n del plan de acci�n <br />(70 %)", 
                                                      ),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido")										  
										  );*/
						"nc" => array("name" => "NC Auditor&iacute;a 2016",
                                          "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                      "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)", 
                                                      "Por verificar y cerrar <br />(10 %)"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido")										  
										  );
               
    public static $LIMITE_PORCENTAJE = 90;
       
	function InformeIceModel() 
    {
		parent::Model();
        $this->MODULO_MODEL = InformeIceModel::$MODULO;
    }
	
    //Se obtiene el arreglo de titulos del informe
    function getTitulos()
    {
        return $this->title;
    }
    
    //Se obtiene el arbol de areas completo
    function arbol_areas()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
    
	//CONSTRUCCION Y FORESTAL
	
	    function arbol_areas_co_fo()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_co_fo";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_co_fo ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_co_fo";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	//DCC
	
	    function arbol_areas_dcc()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_dcc";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_dcc ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_dcc";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	
  //14-05-2019: RH, se agrega para nuevo ice
	  function arbol_areas_drs()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_drs";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_drs ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_drs";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	//KCCA
	
	    function arbol_areas_kcca()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_kcca";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_kcca ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_kcca";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
    //Se calculan los valores CTP + STP
    function calcular_ctp_stp($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual, $nuevas)
    {
		if($nuevas == 0) $fecha_inicio = "20151223";
		//else
		
		$sql = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
		$rs = $this->select($sql);
		if(!$rs->EOF)
        {
			$fecIni = $rs->fields["fec"];
		}
		$fec = explode("/",$fecIni);
		
		$fecha_inicio = "20070101";
		$fecha_inicio = $fec[2].$fec[1].$fec[0];
		
		$sql = "exec ri_informe_ice_calcular_ctp_stp ".$codigo_area.", '".$considera_hijas."', '";
        
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $ctp_stp_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $ctp_stp_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $ctp_stp_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $ctp_stp_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $ctp_stp_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]);
            $ctp_stp_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]);
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $ctp_stp_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$ctp_stp_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $ctp_stp_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$ctp_stp_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $ctp_stp_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$ctp_stp_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                                    
        }
        
        $ctp_stp = array("1" => $ctp_stp_1,
                         "2" => $ctp_stp_2,
                         "3" => $ctp_stp_3);
        
        return $ctp_stp;                        
    }
    
    //Se calculan los valores RESTO
    function calcular_resto($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {
		if($nuevas == 0) $fecha_inicio = "20151223";
		
		$sql = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
		$rs = $this->select($sql);
		if(!$rs->EOF)
        {
			$fecIni = $rs->fields["fec"];
		}
		$fec = explode("/",$fecIni);
		
		$fecha_inicio = "20070101";
		$fecha_inicio = $fec[2].$fec[1].$fec[0];
		
        $sql = "exec ri_informe_ice_calcular_resto ".$codigo_area.", '".$considera_hijas."', '";
        //echo 
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $resto_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $resto_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $resto_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $resto_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
//			print_r($resto_1;
            $resto_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]
							   );
            $resto_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]
							   );           
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $resto_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$resto_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $resto_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$resto_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $resto_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$resto_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                        
        }
        
        $resto = array("1" => $resto_1,
                       "2" => $resto_2,
                       "3" => $resto_3);
        
        return $resto;
    }
        
    //Se calculan los valores SUGERENCIAS
    function calcular_sugerencias($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {
		if($nuevas == 0) $fecha_inicio = "20151223";
		
		$sql = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
		$rs = $this->select($sql);
		if(!$rs->EOF)
        {
			$fecIni = $rs->fields["fec"];
		}
		$fec = explode("/",$fecIni);
		
		$fecha_inicio = "20070101";
		$fecha_inicio = $fec[2].$fec[1].$fec[0];
		
        $sql = "exec ri_informe_ice_calcular_sugerencias ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
            
        $rs = $this->select($sql);
        $sugerencias_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $sugerencias_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);        
        if(!$rs->EOF)
        {               
            $sugerencias_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $sugerencias_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]
							   );
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $sugerencias_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$sugerencias_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
                        
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $sugerencias_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$sugerencias_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }                                    
        }
        
        $sugerencias = array("1" => $sugerencias_1,
                             "2" => $sugerencias_2);
        
        return $sugerencias;               
    }
        
    //Se calculan los valores 
    function calcular_sub_pae($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		//$fecha_inicio = "20130401";
		$sql = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
		$rs = $this->select($sql);
		if(!$rs->EOF)
        {
			$fecIni = $rs->fields["fec"];
		}
		$fec = explode("/",$fecIni);
		
		$fecha_inicio = "20070101";
		$fecha_inicio = $fec[2].$fec[1].$fec[0];
				
        $sql = "exec ri_informe_ice_calcular_sub_pae_3meses ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
                    
        $rs = $this->select($sql);
        $sub_pae_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $sub_pae_1 = array("ok" => $rs->fields["ok"], 
                               "ok_codigos" => $rs->fields["ok_codigos"], 
                               "nok" => $rs->fields["nok"], 
                               "nok_codigos" => $rs->fields["nok_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
                               
            if(($rs->fields["ok"] > 0) || ($rs->fields["nok"] > 0))
            {
                $sub_pae_1["%"] = number_format(100*$rs->fields["ok"]/($rs->fields["ok"] + $rs->fields["nok"]),1);
				$sub_pae_1["%"] = number_format((100*$rs->fields["ok"])/($rs->fields["ok1_total"]),1);
            }            
        }
        
        $sub_pae = array("1" => $sub_pae_1);
        
        return $sub_pae;         
    }
    
    //Se calculan los valores 
    function calcular_nc($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		if($nuevas == 0) $fecha_inicio = "20151223";
		//else
		$sql = "SELECT convert(char(10),DATEADD(mm, -3, GETDATE()),103) as fec";
		$rs = $this->select($sql);
		if(!$rs->EOF)
        {
			$fecIni = $rs->fields["fec"];
		}
		$fec = explode("/",$fecIni);
		
		$fecha_inicio = "20070101";
		$fecha_inicio = $fec[2].$fec[1].$fec[0];
		
		$sql = "exec ri_informe_ice_calcular_nc2 ".$codigo_area.", '".$considera_hijas."', '";
        
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $nc_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $nc_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $nc_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $nc_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $nc_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]);
            $nc_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]);
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $nc_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$nc_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $nc_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$nc_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $nc_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$nc_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                                    
        }
        
        $nc = array("1" => $nc_1,
		
                         "2" => $nc_2,
                         "3" => $nc_3);
        
        return $nc;     
    }
	
    //Se realiza el calculo de % final
    function calcular_porcentaje_area($valores)
    {
        $valor = 0;
        $valor = ($valores["ctp_stp_1"] + $valores["ctp_stp_2"] + $valores["ctp_stp_3"])/3 * $this->PESOS["ctp_stp"];
        $valor += ($valores["resto_1"] + $valores["resto_2"] + $valores["resto_3"]) * $this->PESOS["resto"];
        $valor += ($valores["sugerencias_1"] + $valores["sugerencias_2"]) * $this->PESOS["sugerencias"];
        $valor += ($valores["sub_pae"]) * $this->PESOS["sub_pae"];
		$valor += ($valores["nc_1"] + $valores["nc_2"] + $valores["nc_3"])/3 * $this->PESOS["nc"];//($valores["nc"]) * $this->PESOS["nc"];
        
        return $valor;
    }
    
    //Se realiza el calculo de todos los indices
    function calculo_indices($codigo_area, $considera_hijas = "1",$fecha_desde,$fecha_hasta)
    {
        $fechas = $this->rango_fechas_busqueda();
                
        $indices = array();
        $porcentaje = 0;
		
		$nuevas = 0;
		if($fecha_desde<>'' and $fecha_hasta<>''){
			$fechas["fecha_inicio"] = $fecha_desde;
			$fechas["fecha_fin"] = $fecha_hasta;
			$nuevas = 1;	
		}
		
		//if($fecha_hasta<>'') $fechas["fecha_fin"] = $fecha_hasta;
		
		//echo $fechas["fecha_inicio"]." ".$fechas["fecha_fin"];
		$ctp_stp = $this->calcular_ctp_stp($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);

        $indices["ctp_stp"]["1"]["ok"] = $ctp_stp["1"]["ok"];
        $indices["ctp_stp"]["1"]["ok_codigos"] = $ctp_stp["1"]["ok_codigos"];
        $indices["ctp_stp"]["1"]["nok"] = $ctp_stp["1"]["nok"];
        $indices["ctp_stp"]["1"]["nok_codigos"] = $ctp_stp["1"]["nok_codigos"];        
        $indices["ctp_stp"]["1"]["%"] = $ctp_stp["1"]["%"];
		$indices["ctp_stp"]["1"]["ok_total"] = $ctp_stp["1"]["ok_total"];
        
        $indices["ctp_stp"]["2"]["ok"] = $ctp_stp["2"]["ok"];
        $indices["ctp_stp"]["2"]["ok_codigos"] = $ctp_stp["2"]["ok_codigos"];
        $indices["ctp_stp"]["2"]["nok"] = $ctp_stp["2"]["nok"];
        $indices["ctp_stp"]["2"]["nok_codigos"] = $ctp_stp["2"]["nok_codigos"];
        $indices["ctp_stp"]["2"]["%"] = $ctp_stp["2"]["%"];
		$indices["ctp_stp"]["2"]["ok_total"] = $ctp_stp["2"]["ok_total"];
        
        $indices["ctp_stp"]["3"]["ok"] = $ctp_stp["3"]["ok"];
        $indices["ctp_stp"]["3"]["ok_codigos"] = $ctp_stp["3"]["ok_codigos"];
        $indices["ctp_stp"]["3"]["nok"] = $ctp_stp["3"]["nok"];
        $indices["ctp_stp"]["3"]["nok_codigos"] = $ctp_stp["3"]["nok_codigos"];
        $indices["ctp_stp"]["3"]["%"] = $ctp_stp["3"]["%"];
		$indices["ctp_stp"]["3"]["ok_total"] = $ctp_stp["3"]["ok_total"];
        
        $resto = $this->calcular_resto($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);

        $indices["resto"]["1"]["ok"] = $resto["1"]["ok"];
        $indices["resto"]["1"]["ok_codigos"] = $resto["1"]["ok_codigos"]; 
        $indices["resto"]["1"]["nok"] = $resto["1"]["nok"];
        $indices["resto"]["1"]["nok_codigos"] = $resto["1"]["nok_codigos"];
        $indices["resto"]["1"]["%"] = $resto["1"]["%"];
		$indices["resto"]["1"]["ok_total"] = $resto["1"]["ok_total"];
        
        $indices["resto"]["2"]["ok"] = $resto["2"]["ok"];
        $indices["resto"]["2"]["ok_codigos"] = $resto["2"]["ok_codigos"];
        $indices["resto"]["2"]["nok"] = $resto["2"]["nok"];
        $indices["resto"]["2"]["nok_codigos"] = $resto["2"]["nok_codigos"];
        $indices["resto"]["2"]["%"] = $resto["2"]["%"];
		$indices["resto"]["2"]["ok_total"] = $resto["2"]["ok_total"];
        
        $indices["resto"]["3"]["ok"] = $resto["3"]["ok"];
        $indices["resto"]["3"]["ok_codigos"] = $resto["3"]["ok_codigos"];
        $indices["resto"]["3"]["nok"] = $resto["3"]["nok"];
        $indices["resto"]["3"]["nok_codigos"] = $resto["3"]["nok_codigos"];
        $indices["resto"]["3"]["%"] = $resto["3"]["%"];
		$indices["resto"]["3"]["ok_total"] = $resto["3"]["ok_total"];
        
        $sugerencias = $this->calcular_sugerencias($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
        
        $indices["sugerencias"]["1"]["ok"] = $sugerencias["1"]["ok"];
        $indices["sugerencias"]["1"]["ok_codigos"] = $sugerencias["1"]["ok_codigos"];
        $indices["sugerencias"]["1"]["nok"] = $sugerencias["1"]["nok"];
        $indices["sugerencias"]["1"]["nok_codigos"] = $sugerencias["1"]["nok_codigos"];
        $indices["sugerencias"]["1"]["%"] = $sugerencias["1"]["%"];
		$indices["sugerencias"]["1"]["ok_total"] = $sugerencias["1"]["ok_total"];
        
        $indices["sugerencias"]["2"]["ok"] = $sugerencias["2"]["ok"];
        $indices["sugerencias"]["2"]["ok_codigos"] = $sugerencias["2"]["ok_codigos"];
        $indices["sugerencias"]["2"]["nok"] = $sugerencias["2"]["nok"];
        $indices["sugerencias"]["2"]["nok_codigos"] = $sugerencias["2"]["nok_codigos"];
        $indices["sugerencias"]["2"]["%"] = $sugerencias["2"]["%"];
		$indices["sugerencias"]["2"]["ok_total"] = $sugerencias["2"]["ok_total"];
                        
        $sub_pae = $this->calcular_sub_pae($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
        
        $indices["sub_pae"]["1"]["ok"] = $sub_pae["1"]["ok"];
        $indices["sub_pae"]["1"]["ok_codigos"] = $sub_pae["1"]["ok_codigos"];
        $indices["sub_pae"]["1"]["nok"] = $sub_pae["1"]["nok"];
        $indices["sub_pae"]["1"]["nok_codigos"] = $sub_pae["1"]["nok_codigos"];
        $indices["sub_pae"]["1"]["%"] = $sub_pae["1"]["%"];
		$indices["sub_pae"]["1"]["ok_total"] = $sub_pae["1"]["ok_total"];

		$nc = $this->calcular_nc($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
		//print_r($nc);
		
        $indices["nc"]["1"]["ok"] = $nc["1"]["ok"];
        $indices["nc"]["1"]["ok_codigos"] = $nc["1"]["ok_codigos"];
        $indices["nc"]["1"]["nok"] = $nc["1"]["nok"];
        $indices["nc"]["1"]["nok_codigos"] = $nc["1"]["nok_codigos"];        
        $indices["nc"]["1"]["%"] = $nc["1"]["%"];
		$indices["nc"]["1"]["ok_total"] = $nc["1"]["ok_total"];
        
        $indices["nc"]["2"]["ok"] = $nc["2"]["ok"];
        $indices["nc"]["2"]["ok_codigos"] = $nc["2"]["ok_codigos"];
        $indices["nc"]["2"]["nok"] = $nc["2"]["nok"];
        $indices["nc"]["2"]["nok_codigos"] = $nc["2"]["nok_codigos"];
        $indices["nc"]["2"]["%"] = $nc["2"]["%"];
		$indices["nc"]["2"]["ok_total"] = $nc["2"]["ok_total"];
        
        $indices["nc"]["3"]["ok"] = $nc["3"]["ok"];
        $indices["nc"]["3"]["ok_codigos"] = $nc["3"]["ok_codigos"];
        $indices["nc"]["3"]["nok"] = $nc["3"]["nok"];
        $indices["nc"]["3"]["nok_codigos"] = $nc["3"]["nok_codigos"];
        $indices["nc"]["3"]["%"] = $nc["3"]["%"];
		$indices["nc"]["3"]["ok_total"] = $nc["3"]["ok_total"];
		
        $indices = $this->aplicar_distribucion($indices, $codigo_area);
                
        $lista["indices"] = $indices;
        //print_r($lista);
        return $lista;
    }
    
    //Se obtienen las fechas de inicio y fin del informe, Fiscal Year
    function rango_fechas_busqueda()
    {
        $fecha = new Fecha();
        $ano_actual = $fecha->getAno();
        $fecha_actual = $fecha->amdNumerico();        
        $ano_actual = $fecha->getAno();
        
        $fecha_inicio = $fecha->fiscalYear(); //$ano_actual."0401";
		$fecha_fin = date('Ymd'); //Nuevo 29-06-2012
		
        /*$fecha_fin = $ano_actual."0331";

        if($ano_actual < 2012)
        {
            $fecha_fin = $fecha_actual;
			//echo "hola";
        }
        else
        {            
            $fecha_fin = $fecha_actual;            
            $fecha_inicio = $fecha->restarTiempo(1);
            $fecha_inicio = str_replace("-", "", $fecha_inicio);
        } */               
        
        $fechas = array("fecha_actual" => $fecha_actual, 
                        "fecha_inicio" => $fecha_inicio,
                        "fecha_fin" => $fecha_fin);
                
        //echo "Fechas 5:";
        //print_r($fechas);
        
        return $fechas;        
    }        
    
    //Se realiza la actualizaci�n de fechas de envio de planes de accion
    function actualizar_fechas()
    {
        $sql = "exec ri_informe_ice_aseguramiento_reporte_lista_correlativos";
        $lista = $this->select_list($sql);        
        if(is_array($lista) && (count($lista) > 0))
        {
            $contador = 1;
            foreach($lista as $correlativo)
            {                
                 $sql = "exec ri_informe_ice_aseguramiento_reporte_conversion_fecha '".$correlativo["idn_correlativo"]."'";
                 $sql .= ", '".date('Ymd H:m:s', $correlativo["idn_correlativo"])."'";
                 
                 //echo "<br>Contador: ".$contador;                 
                 $rs = $this->select($sql);
                 //$contador++;
            }
        }
    }
    
    /*******************************************************************************
    * 
    *                   DISTRIBUCION DE PESOS
    * 
    ********************************************************************************/
    
    //Se realiza la distribucion de los valores
    function aplicar_distribucion($indices, $id_area)
    {
        $total_indices = 9;
        $contador = 0;
        $keys = array_keys($this->PESOS);
        //print_r($indices);
		//exit(0);
        /*
         *           DISTRIBUCION
         */
        
        $suma_porcentajes_items = 0;
        foreach($keys as $key)
        {                                        
            $subitems = count($this->PESOS[$key]["pesos_subitems"]);
            $indices[$key]["peso_final"] = 0;
            
            //Se calculan los porcentajes que participan de la distribucion
            $suma_porcentajes = 0;
            $peso_corregido = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                if(($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0))
                {
					//echo "Key. $key ".$this->PESOS[$key]["pesos_subitems"]["$i"]."<br>";
                    $suma_porcentajes += $this->PESOS[$key]["pesos_subitems"]["$i"];
                    $peso_corregido += $this->PESOS[$key]["pesos_subitems"]["$i"];
                }                
            }  
			//echo "suma porcentajes: ".$suma_porcentajes;
             //echo "<br><br>";    
            //Calculo porcentaje sub-item       
            $porcentaje_real = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                $porcentaje_real = 0;
                if(($suma_porcentajes > 0) && (($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0)))
                {
                    $porcentaje_real = ($this->PESOS[$key]["pesos_subitems"]["$i"]*100) / $suma_porcentajes;
                }                                
                $indices[$key]["$i"]["porcentaje_real"] = $porcentaje_real;                    
               //echo "ICE : $key -> $i: ".
			   $indices[$key]["$i"]["ice"] = ($indices[$key]["$i"]["%"]*$porcentaje_real)/100;
			   //echo "<br>";
				//echo "Key: $key: ".$indices[$key]["$i"]["%"]." % Real: ".$porcentaje_real."<br>";;
                $indices[$key]["peso_final"] += $indices[$key]["$i"]["ice"];
            }
            
            //Peso final del item
            //echo "Peso final: $key ".
			$indices[$key]["peso_final"] = $indices[$key]["peso_final"]."<br>";
            $indices[$key]["peso_corregido"] = $peso_corregido;
                                        
            //$suma_porcentajes = 0;
            if($indices[$key]["peso_final"] > 0)
            {
                $suma_porcentajes_items += $this->PESOS[$key]["peso_item"];
            }        
			//$indices[$key]["peso_final"] = 50;                                                            
        }                                
        
        $indices["ice"] = 0;
        if($suma_porcentajes_items > 0)
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $sumar_ice = 0;
            foreach($keys as $key)
            {
                $indices[$key]["peso_final_item"] = $indices[$key]["peso_final"] * $this->PESOS[$key]["peso_item"] / 100;
                $sumar_ice = $indices[$key]["peso_final"] * ((100 * $this->PESOS[$key]["peso_item"]) / $suma_porcentajes_items) / 100; 
                //$indices["ice"] += $indices[$key]["peso_final_item"];
                $indices["ice"] += $sumar_ice;
            }

            //echo "ICE: ".
			$indices["ice"] = number_format($indices["ice"],1);
			//."<br>";
        }
        else
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $indices["ice"] = 0;                    
        }
               
        
        /*if($id_area == 37){
            echo "<br>% Item: ".$suma_porcentajes_items;                              
        }
                
        if($id_area == 37)
        {
            echo "<pre>";
            print_r($indices);
            echo "</pre>";
        }*/
//print_r($indices);
        return $indices;
    }
}



class InformeIceModelSC extends Model
{
    public static $MODULO = "informe_ice";

    var $PESOS = array("ctp_stp"        => array("peso_item" => 35, "pesos_subitems" => array("1" => 20, "2" => 70, "3" => 10)), 
                       "resto"          => array("peso_item" => 10, "pesos_subitems" => array("1" => 20, "2" => 70, "3" => 10)), 
                       "sugerencias"    => array("peso_item" => 5,  "pesos_subitems" => array("1" => 30, "2" => 70)), 
                       "sub_pae"        => array("peso_item" => 40, "pesos_subitems" => array("1" => 100)),
					   "nc"          => array("peso_item" => 10, "pesos_subitems" => array("1" => 100)));    
     
    var $title = array("incidentes" => array("name" => ""),
                       "ctp_stp"    => array("name" => "ACCIDENTES CTP + STP (12 meses flotantes)", 
                                             "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                      "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)", 
                                                      "Por verificar y cerrar <br />(10 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "resto"      => array("name" => "RESTO DE INCIDENTES + NO CONFORMIDADES + TRANSGRESIONES (12 meses flotantes)", 
                                             "indice" => array("Por revisar y hacer plan de acci&oacute;n <br />(20 %)", 
                                                    "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)",
                                                    "Por verificar y cerrar <br />(10 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "sugerencias" => array("name" => "IDEAS DE MEJORA + TRATAMIENTO DE ACCIONES Y CONDICIONES SUBESTANDARES (12 meses flotantes)", 
                                             "indice" => array("Por revisar <br />(30 %)",
                                                          "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)"),
                                             "porcentaje" => "% &Iacute;tem",
                                             "corregido" => "Peso Corregido"),
                       "sub_pae" => array("name" => "ACTIVIDADES DEL PROGRAMA PREVENTIVO FY18 (Se mide A&ntilde;o fiscal al d&iacute;a)",
                                          "indice" => array("Actividades programa preventivo"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido"),
						"nc" => array("name" => "NC Auditor&iacute;a 2016",
                                          "indice" => array( 
                                                      "En implementaci&oacute;n del plan de acci&oacute;n <br />(70 %)", 
                                                      ),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido")										  
										  );
						/*"nc" => array("name" => "NC Auditor�a 2015",
                                          "indice" => array("Por revisar y hacer plan de acci�n <br />(20 %)", 
                                                      "En implementaci�n del plan de acci�n <br />(70 %)", 
                                                      "Por verificar y cerrar <br />(10 %)"),
                                          "porcentaje" => "% &Iacute;tem",
                                          "corregido" => "Peso Corregido")										  
										  );*/
               
    public static $LIMITE_PORCENTAJE = 90;
       
	function InformeIceModel() 
    {
		parent::Model();
        $this->MODULO_MODEL = InformeIceModel::$MODULO;
    }
	
    //Se obtiene el arreglo de titulos del informe
    function getTitulos()
    {
        return $this->title;
    }
    
    //Se obtiene el arbol de areas completo
    function arbol_areas()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
    
	//CONSTRUCCION Y FORESTAL
	
	    function arbol_areas_co_fo()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_co_fo";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_co_fo ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_co_fo";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	
	    function arbol_areas_kcc()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_kcc";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_kcc ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_kcc";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }	
	
	
	//DCC
	
	    function arbol_areas_dcc()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_dcc";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_dcc ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_dcc";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	
  //14-05-2019: RH, se agrega para nuevo ice
	  function arbol_areas_drs()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_drs";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_drs ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_drs";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
	//KCCA
	
	    function arbol_areas_kcca()
    {
        $areas = array();
        
        $sql = "exec ri_informe_ice_area_informe_principales_kcca";
                
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $principales = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $principales[] = $area;
                $rs->MoveNext();
            }
            
            foreach($principales as $area)
            {
                $sql = "exec ri_informe_ice_area_informe_hijas_kcca ".$area["id"];
                                
                $rs = $this->select($sql);        
                if(!$rs->EOF)
                {
                    $hijas = array();            
                    while(!$rs->EOF)
                    {
                        $area_hija = $rs->fields;
                        $area_hija["nombre_usuario"] = ucwords($area_hija["nombre_usuario"]);
                        $hijas[] = $area_hija;                
                        $rs->MoveNext();
                    }         
                       
                    $area["hijas"] = $hijas;                    
                }                           
                $areas["principales"][] = $area; 
            }                        
        }
                        
        $sql = "exec ri_informe_ice_area_informe_resumen_kcca";
        $rs = $this->select($sql);        
        if(!$rs->EOF)
        {
            $resumen = array();            
            while(!$rs->EOF)
            {
                $area = $rs->fields;
                $area["nombre_usuario"] = ucwords($area["nombre_usuario"]);
                $resumen[] = $area;
                
                $rs->MoveNext();
            }
            
            $areas["resumen"] = $resumen;
        }
        
        return $areas;
    }
	
    //Se calculan los valores CTP + STP
    function calcular_ctp_stp($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual, $nuevas)
    {
		if($nuevas == 0) $fecha_inicio = "20151223";
		//else
        $sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
		$sql = "exec ri_informe_ice_calcular_ctp_stp ".$codigo_area.", '".$considera_hijas."', '";
        
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $ctp_stp_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $ctp_stp_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $ctp_stp_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $ctp_stp_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $ctp_stp_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]);
            $ctp_stp_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]);
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $ctp_stp_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$ctp_stp_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $ctp_stp_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$ctp_stp_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $ctp_stp_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$ctp_stp_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                                    
        }
        
        $ctp_stp = array("1" => $ctp_stp_1,
                         "2" => $ctp_stp_2,
                         "3" => $ctp_stp_3);
        
        return $ctp_stp;                        
    }
    
    //Se calculan los valores RESTO
    function calcular_resto($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {
		if($nuevas == 0) $fecha_inicio = "20151223";
		
		$sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
        $sql = "exec ri_informe_ice_calcular_resto ".$codigo_area.", '".$considera_hijas."', '";
        //echo 
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $resto_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $resto_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $resto_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $resto_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
//			print_r($resto_1;
            $resto_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]
							   );
            $resto_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]
							   );           
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $resto_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$resto_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $resto_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$resto_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $resto_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$resto_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                        
        }
        
        $resto = array("1" => $resto_1,
                       "2" => $resto_2,
                       "3" => $resto_3);
        
        return $resto;
    }
        
    //Se calculan los valores SUGERENCIAS
    function calcular_sugerencias($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {
		if($nuevas == 0) $fecha_inicio = "20151223";
		
		$sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
        $sql = "exec ri_informe_ice_calcular_sugerencias ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
            
        $rs = $this->select($sql);
        $sugerencias_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $sugerencias_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);        
        if(!$rs->EOF)
        {               
            $sugerencias_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $sugerencias_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]
							   );
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $sugerencias_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$sugerencias_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
                        
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $sugerencias_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$sugerencias_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }                                    
        }
        
        $sugerencias = array("1" => $sugerencias_1,
                             "2" => $sugerencias_2);
        
        return $sugerencias;               
    }
        
    //Se calculan los valores 
    function calcular_sub_pae($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		//$fecha_inicio = "20130401";
		
        $sql = "exec ri_informe_ice_calcular_sub_pae ".$codigo_area.", '".$considera_hijas."', '";
        //echo "<br>".
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
                    
        $rs = $this->select($sql);
        $sub_pae_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $sub_pae_1 = array("ok" => $rs->fields["ok"], 
                               "ok_codigos" => $rs->fields["ok_codigos"], 
                               "nok" => $rs->fields["nok"], 
                               "nok_codigos" => $rs->fields["nok_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
                               
            if(($rs->fields["ok"] > 0) || ($rs->fields["nok"] > 0))
            {
                $sub_pae_1["%"] = number_format(100*$rs->fields["ok"]/($rs->fields["ok"] + $rs->fields["nok"]),1);
				$sub_pae_1["%"] = number_format((100*$rs->fields["ok"])/($rs->fields["ok1_total"]),1);
            }            
        }
        
        $sub_pae = array("1" => $sub_pae_1);
        
        return $sub_pae;         
    }
    
    //Se calculan los valores 
    function calcular_nc($codigo_area, $considera_hijas, $fecha_inicio, $fecha_termino, $fecha_actual)
    {        
		if($nuevas == 0) $fecha_inicio = "20151223";
		//else
        $sql = "select convert(char(10),dateadd(year,-1,getdate()),103)";
		$rec_fec = mssql_query($sql);
		$row_fec = mssql_fetch_array($rec_fec);
		
		$fe = explode('/',$row_fec[0]);
		$fecha_inicio = $fe[2]."".$fe[1]."".$fe[0];
		
		$sql = "exec ri_informe_ice_calcular_nc2 ".$codigo_area.", '".$considera_hijas."', '";
        
		$sql .= $fecha_inicio."', '".$fecha_termino."', '".$fecha_actual."'";
        //echo "<br>";    
        $rs = $this->select($sql);
        $ctp_stp_1 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "", "%" => 0, "ok_total" => 0);
        $ctp_stp_2 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        $ctp_stp_3 = array("ok" => 0, "ok_codigos" => "", "nok" => 0, "nok_codigos" => "",  "%" => 0, "ok_total" => 0);
        if(!$rs->EOF)
        {               
            $ctp_stp_1 = array("ok" => $rs->fields["ok_1"], 
                               "ok_codigos" => $rs->fields["ok_1_codigos"], 
                               "nok" => $rs->fields["nok_1"], 
                               "nok_codigos" => $rs->fields["nok_1_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok1_total"]
							   );
            $ctp_stp_2 = array("ok" => $rs->fields["ok_2"], 
                               "ok_codigos" => $rs->fields["ok_2_codigos"], 
                               "nok" => $rs->fields["nok_2"], 
                               "nok_codigos" => $rs->fields["nok_2_codigos"],
                               "%" => 0,
							   "ok_total" => $rs->fields["ok2_total"]);
            $ctp_stp_3 = array("ok" => $rs->fields["ok_3"], 
                               "ok_codigos" => $rs->fields["ok_3_codigos"], 
                               "nok" => $rs->fields["nok_3"],
                               "nok_codigos" => $rs->fields["nok_3_codigos"], 
                               "%" => 0,
							   "ok_total" => $rs->fields["ok3_total"]);
            
            if(($rs->fields["ok_1"] > 0) || ($rs->fields["nok_1"] > 0))
            {
                $ctp_stp_1["%"] = number_format(100*$rs->fields["ok_1"]/($rs->fields["ok_1"] + $rs->fields["nok_1"]),1);
				$ctp_stp_1["%"] = number_format((100*$rs->fields["ok_1"])/($rs->fields["ok1_total"]),1);
            }            
            
            if(($rs->fields["ok_2"] > 0) || ($rs->fields["nok_2"] > 0))
            {
                $ctp_stp_2["%"] = number_format(100*$rs->fields["ok_2"]/($rs->fields["ok_2"] + $rs->fields["nok_2"]),1);
				$ctp_stp_2["%"] = number_format((100*$rs->fields["ok_2"])/($rs->fields["ok2_total"]),1);
            }            
            
            if(($rs->fields["ok_3"] > 0) || ($rs->fields["nok_3"] > 0))
            {
                $ctp_stp_3["%"] = number_format(100*$rs->fields["ok_3"]/($rs->fields["ok_3"] + $rs->fields["nok_3"]),1);
				$ctp_stp_3["%"] = number_format((100*$rs->fields["ok_3"])/($rs->fields["ok3_total"]),1);
            }                                    
        }
        
        $nc = array("2" => $ctp_stp_2);
		/*,
                         "2" => $ctp_stp_2,
                         "3" => $ctp_stp_3);*/
        
        return $nc;     
    }
	
    //Se realiza el calculo de % final
    function calcular_porcentaje_area($valores)
    {
        $valor = 0;
        $valor = ($valores["ctp_stp_1"] + $valores["ctp_stp_2"] + $valores["ctp_stp_3"])/3 * $this->PESOS["ctp_stp"];
        $valor += ($valores["resto_1"] + $valores["resto_2"] + $valores["resto_3"]) * $this->PESOS["resto"];
        $valor += ($valores["sugerencias_1"] + $valores["sugerencias_2"]) * $this->PESOS["sugerencias"];
        $valor += ($valores["sub_pae"]) * $this->PESOS["sub_pae"];
		$valor += ($valores["nc"]) * $this->PESOS["nc"];
        
        return $valor;
    }
    
    //Se realiza el calculo de todos los indices
    function calculo_indices_kcc($codigo_area, $considera_hijas = "1",$fecha_desde,$fecha_hasta)
    {
        $fechas = $this->rango_fechas_busqueda();
                
        $indices = array();
        $porcentaje = 0;
		
		$nuevas = 0;
		if($fecha_desde<>'' and $fecha_hasta<>''){
			$fechas["fecha_inicio"] = $fecha_desde;
			$fechas["fecha_fin"] = $fecha_hasta;
			$nuevas = 1;	
		}
		
		//if($fecha_hasta<>'') $fechas["fecha_fin"] = $fecha_hasta;
		
		//echo $fechas["fecha_inicio"]." ".$fechas["fecha_fin"];
		$ctp_stp = $this->calcular_ctp_stp($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);

        $indices["ctp_stp"]["1"]["ok"] = $ctp_stp["1"]["ok"];
        $indices["ctp_stp"]["1"]["ok_codigos"] = $ctp_stp["1"]["ok_codigos"];
        $indices["ctp_stp"]["1"]["nok"] = $ctp_stp["1"]["nok"];
        $indices["ctp_stp"]["1"]["nok_codigos"] = $ctp_stp["1"]["nok_codigos"];        
        $indices["ctp_stp"]["1"]["%"] = $ctp_stp["1"]["%"];
		$indices["ctp_stp"]["1"]["ok_total"] = $ctp_stp["1"]["ok_total"];
        
        $indices["ctp_stp"]["2"]["ok"] = $ctp_stp["2"]["ok"];
        $indices["ctp_stp"]["2"]["ok_codigos"] = $ctp_stp["2"]["ok_codigos"];
        $indices["ctp_stp"]["2"]["nok"] = $ctp_stp["2"]["nok"];
        $indices["ctp_stp"]["2"]["nok_codigos"] = $ctp_stp["2"]["nok_codigos"];
        $indices["ctp_stp"]["2"]["%"] = $ctp_stp["2"]["%"];
		$indices["ctp_stp"]["2"]["ok_total"] = $ctp_stp["2"]["ok_total"];
        
        $indices["ctp_stp"]["3"]["ok"] = $ctp_stp["3"]["ok"];
        $indices["ctp_stp"]["3"]["ok_codigos"] = $ctp_stp["3"]["ok_codigos"];
        $indices["ctp_stp"]["3"]["nok"] = $ctp_stp["3"]["nok"];
        $indices["ctp_stp"]["3"]["nok_codigos"] = $ctp_stp["3"]["nok_codigos"];
        $indices["ctp_stp"]["3"]["%"] = $ctp_stp["3"]["%"];
		$indices["ctp_stp"]["3"]["ok_total"] = $ctp_stp["3"]["ok_total"];
        
        $resto = $this->calcular_resto($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);

        $indices["resto"]["1"]["ok"] = $resto["1"]["ok"];
        $indices["resto"]["1"]["ok_codigos"] = $resto["1"]["ok_codigos"]; 
        $indices["resto"]["1"]["nok"] = $resto["1"]["nok"];
        $indices["resto"]["1"]["nok_codigos"] = $resto["1"]["nok_codigos"];
        $indices["resto"]["1"]["%"] = $resto["1"]["%"];
		$indices["resto"]["1"]["ok_total"] = $resto["1"]["ok_total"];
        
        $indices["resto"]["2"]["ok"] = $resto["2"]["ok"];
        $indices["resto"]["2"]["ok_codigos"] = $resto["2"]["ok_codigos"];
        $indices["resto"]["2"]["nok"] = $resto["2"]["nok"];
        $indices["resto"]["2"]["nok_codigos"] = $resto["2"]["nok_codigos"];
        $indices["resto"]["2"]["%"] = $resto["2"]["%"];
		$indices["resto"]["2"]["ok_total"] = $resto["2"]["ok_total"];
        
        $indices["resto"]["3"]["ok"] = $resto["3"]["ok"];
        $indices["resto"]["3"]["ok_codigos"] = $resto["3"]["ok_codigos"];
        $indices["resto"]["3"]["nok"] = $resto["3"]["nok"];
        $indices["resto"]["3"]["nok_codigos"] = $resto["3"]["nok_codigos"];
        $indices["resto"]["3"]["%"] = $resto["3"]["%"];
		$indices["resto"]["3"]["ok_total"] = $resto["3"]["ok_total"];
        
        $sugerencias = $this->calcular_sugerencias($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
        
        $indices["sugerencias"]["1"]["ok"] = $sugerencias["1"]["ok"];
        $indices["sugerencias"]["1"]["ok_codigos"] = $sugerencias["1"]["ok_codigos"];
        $indices["sugerencias"]["1"]["nok"] = $sugerencias["1"]["nok"];
        $indices["sugerencias"]["1"]["nok_codigos"] = $sugerencias["1"]["nok_codigos"];
        $indices["sugerencias"]["1"]["%"] = $sugerencias["1"]["%"];
		$indices["sugerencias"]["1"]["ok_total"] = $sugerencias["1"]["ok_total"];
        
        $indices["sugerencias"]["2"]["ok"] = $sugerencias["2"]["ok"];
        $indices["sugerencias"]["2"]["ok_codigos"] = $sugerencias["2"]["ok_codigos"];
        $indices["sugerencias"]["2"]["nok"] = $sugerencias["2"]["nok"];
        $indices["sugerencias"]["2"]["nok_codigos"] = $sugerencias["2"]["nok_codigos"];
        $indices["sugerencias"]["2"]["%"] = $sugerencias["2"]["%"];
		$indices["sugerencias"]["2"]["ok_total"] = $sugerencias["2"]["ok_total"];
                        
        $sub_pae = $this->calcular_sub_pae($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
        
        $indices["sub_pae"]["1"]["ok"] = $sub_pae["1"]["ok"];
        $indices["sub_pae"]["1"]["ok_codigos"] = $sub_pae["1"]["ok_codigos"];
        $indices["sub_pae"]["1"]["nok"] = $sub_pae["1"]["nok"];
        $indices["sub_pae"]["1"]["nok_codigos"] = $sub_pae["1"]["nok_codigos"];
        $indices["sub_pae"]["1"]["%"] = $sub_pae["1"]["%"];
		$indices["sub_pae"]["1"]["ok_total"] = $sub_pae["1"]["ok_total"];

		$nc = $this->calcular_nc($codigo_area, $considera_hijas, $fechas["fecha_inicio"], $fechas["fecha_fin"], $fechas["fecha_actual"],$nuevas);
		//print_r($nc);
		
        /*$indices["nc"]["1"]["ok"] = $nc["1"]["ok"];
        $indices["nc"]["1"]["ok_codigos"] = $nc["1"]["ok_codigos"];
        $indices["nc"]["1"]["nok"] = $nc["1"]["nok"];
        $indices["nc"]["1"]["nok_codigos"] = $nc["1"]["nok_codigos"];        
        $indices["nc"]["1"]["%"] = $nc["1"]["%"];
		$indices["nc"]["1"]["ok_total"] = $nc["1"]["ok_total"];*/
        
        $indices["nc"]["1"]["ok"] = $nc["2"]["ok"];
        $indices["nc"]["1"]["ok_codigos"] = $nc["2"]["ok_codigos"];
        $indices["nc"]["1"]["nok"] = $nc["2"]["nok"];
        $indices["nc"]["1"]["nok_codigos"] = $nc["2"]["nok_codigos"];
        $indices["nc"]["1"]["%"] = $nc["2"]["%"];
		$indices["nc"]["1"]["ok_total"] = $nc["2"]["ok_total"];
        
        /*$indices["nc"]["3"]["ok"] = $nc["3"]["ok"];
        $indices["nc"]["3"]["ok_codigos"] = $nc["3"]["ok_codigos"];
        $indices["nc"]["3"]["nok"] = $nc["3"]["nok"];
        $indices["nc"]["3"]["nok_codigos"] = $nc["3"]["nok_codigos"];
        $indices["nc"]["3"]["%"] = $nc["3"]["%"];
		$indices["nc"]["3"]["ok_total"] = $nc["3"]["ok_total"];*/
		
        $indices = $this->aplicar_distribucion($indices, $codigo_area);
                
        $lista["indices"] = $indices;
        //print_r($lista);
        return $lista;
    }
    
    //Se obtienen las fechas de inicio y fin del informe, Fiscal Year
    function rango_fechas_busqueda()
    {
        $fecha = new Fecha();
        $ano_actual = $fecha->getAno();
        $fecha_actual = $fecha->amdNumerico();        
        $ano_actual = $fecha->getAno();
        
        $fecha_inicio = $fecha->fiscalYear(); //$ano_actual."0401";
		$fecha_fin = date('Ymd'); //Nuevo 29-06-2012
		
        /*$fecha_fin = $ano_actual."0331";

        if($ano_actual < 2012)
        {
            $fecha_fin = $fecha_actual;
			//echo "hola";
        }
        else
        {            
            $fecha_fin = $fecha_actual;            
            $fecha_inicio = $fecha->restarTiempo(1);
            $fecha_inicio = str_replace("-", "", $fecha_inicio);
        } */               
        
        $fechas = array("fecha_actual" => $fecha_actual, 
                        "fecha_inicio" => $fecha_inicio,
                        "fecha_fin" => $fecha_fin);
                
        return $fechas;        
    }        
    
    //Se realiza la actualizaci�n de fechas de envio de planes de accion
    function actualizar_fechas()
    {
        $sql = "exec ri_informe_ice_aseguramiento_reporte_lista_correlativos";
        $lista = $this->select_list($sql);        
        if(is_array($lista) && (count($lista) > 0))
        {
            $contador = 1;
            foreach($lista as $correlativo)
            {                
                 $sql = "exec ri_informe_ice_aseguramiento_reporte_conversion_fecha '".$correlativo["idn_correlativo"]."'";
                 $sql .= ", '".date('Ymd H:m:s', $correlativo["idn_correlativo"])."'";
                 
                 //echo "<br>Contador: ".$contador;                 
                 $rs = $this->select($sql);
                 //$contador++;
            }
        }
    }
    
    /*******************************************************************************
    * 
    *                   DISTRIBUCION DE PESOS
    * 
    ********************************************************************************/
    
    //Se realiza la distribucion de los valores
    function aplicar_distribucion($indices, $id_area)
    {
        $total_indices = 9;
        $contador = 0;
        $keys = array_keys($this->PESOS);
        //print_r($indices);
		//exit(0);
        /*
         *           DISTRIBUCION
         */
        
        $suma_porcentajes_items = 0;
        foreach($keys as $key)
        {                                        
            $subitems = count($this->PESOS[$key]["pesos_subitems"]);
            $indices[$key]["peso_final"] = 0;
            
            //Se calculan los porcentajes que participan de la distribucion
            $suma_porcentajes = 0;
            $peso_corregido = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                if(($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0))
                {
					//echo "Key. $key ".$this->PESOS[$key]["pesos_subitems"]["$i"]."<br>";
                    $suma_porcentajes += $this->PESOS[$key]["pesos_subitems"]["$i"];
                    $peso_corregido += $this->PESOS[$key]["pesos_subitems"]["$i"];
                }                
            }  
			//echo "suma porcentajes: ".$suma_porcentajes;
             //echo "<br><br>";    
            //Calculo porcentaje sub-item       
            $porcentaje_real = 0;
            for($i=1;$i <= $subitems;$i++)
            {
                $porcentaje_real = 0;
                if(($suma_porcentajes > 0) && (($indices[$key]["$i"]["ok"] > 0) || ($indices[$key]["$i"]["nok"] > 0)))
                {
                    $porcentaje_real = ($this->PESOS[$key]["pesos_subitems"]["$i"]*100) / $suma_porcentajes;
                }                                
                $indices[$key]["$i"]["porcentaje_real"] = $porcentaje_real;                    
               //echo "ICE : $key -> $i: ".
			   $indices[$key]["$i"]["ice"] = ($indices[$key]["$i"]["%"]*$porcentaje_real)/100;
			   //echo "<br>";
				//echo "Key: $key: ".$indices[$key]["$i"]["%"]." % Real: ".$porcentaje_real."<br>";;
                $indices[$key]["peso_final"] += $indices[$key]["$i"]["ice"];
            }
            
            //Peso final del item
            //echo "Peso final: $key ".
			$indices[$key]["peso_final"] = $indices[$key]["peso_final"]."<br>";
            $indices[$key]["peso_corregido"] = $peso_corregido;
                                        
            //$suma_porcentajes = 0;
            if($indices[$key]["peso_final"] > 0)
            {
                $suma_porcentajes_items += $this->PESOS[$key]["peso_item"];
            }        
			//$indices[$key]["peso_final"] = 50;                                                            
        }                                
        
        $indices["ice"] = 0;
        if($suma_porcentajes_items > 0)
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $sumar_ice = 0;
            foreach($keys as $key)
            {
                $indices[$key]["peso_final_item"] = $indices[$key]["peso_final"] * $this->PESOS[$key]["peso_item"] / 100;
                $sumar_ice = $indices[$key]["peso_final"] * ((100 * $this->PESOS[$key]["peso_item"]) / $suma_porcentajes_items) / 100; 
                //$indices["ice"] += $indices[$key]["peso_final_item"];
                $indices["ice"] += $sumar_ice;
            }

            //echo "ICE: ".
			$indices["ice"] = number_format($indices["ice"],1);
			//."<br>";
        }
        else
        {
            $indices["porcentaje_final"] = 0;
            $indices[$key]["porcentaje_final"] = 0;
            $indices[$key]["peso_final_item"] = 0;
            $indices["ice"] = 0;                    
        }
               
        
        /*if($id_area == 37){
            echo "<br>% Item: ".$suma_porcentajes_items;                              
        }
                
        if($id_area == 37)
        {
            echo "<pre>";
            print_r($indices);
            echo "</pre>";
        }*/
//print_r($indices);
        return $indices;
    }
}
?>
